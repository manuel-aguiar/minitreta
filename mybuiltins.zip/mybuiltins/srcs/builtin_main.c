/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtin_main.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/01 12:01:39 by marvin            #+#    #+#             */
/*   Updated: 2023/08/24 15:03:47 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*

Recebe um unico comando, assume que a sintax está correcta
Cria uma estructura MS que tem as environment variables.

A estructura para já toma fd 0 para input e fd 1 para output, o basico.
Quando fizeres as coisas, usa o ft_putstr_fd, porque vao mudar quando tiver completo
Tenho um ft_printf_fd (= dprintf do stdio.h) mas nao podemos usar o nosso proprio printf,
por isso os erros têm de ser mais ou menos à "pata"
{
	ft_putstr_fd(ms->name, STDERR_FILENO);
	ft_putstr_fd(": export: `", STDERR_FILENO);
	ft_putstr_fd(av[i], STDERR_FILENO);
	ft_putstr_fd("': not a valid identifier\n", STDERR_FILENO);
}

Objectivo: executar o comando, printar igual ao bash, guardar o exit_status na estructura MS.



*/

#include "minishell.h"

int	free_all(t_ms *ms)
{
	(void)ms;
	return (0);
}


int init_ms(t_ms *ms, char **env)
{
	if (!ft_charmatdup(&ms->env, env))
		return (free_all(ms));
	ft_strlcpy(ms->name, MYNAME, sizeof(ms->name));
	ms->cur_in = STDIN_FILENO;
	ms->cur_out = STDOUT_FILENO;
	return (1);
}


int	main(int ac, char **av, char **env)
{
	t_ms	ms;
	int		i;
	char	**args;
	int		count;

	if (!init_ms(&ms, env))
		return (0);

	//export_bi(&ms, 0, NULL);
	//printf("\n\n\n");

	i = 0;
	--ac;
	++av;
	while (i < ac)
	{
		args = ft_split_count(av[i], " ", &count);
		unset_bi(&ms, count, args);
		ft_free_charmat_null(&args, free);
		//int j = 0;
		//while (ms.env[j])
		//	printf("%s\n", ms.env[j++]);
		i++;
		//printf("\n\n\n");
	}

	export_bi(&ms, 0, NULL);
	printf("\n\n\n");

	return (0);
}

