/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bi_pwd.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/23 17:59:32 by marvin            #+#    #+#             */
/*   Updated: 2023/08/23 17:59:32 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/* Aproveita e faz me uma função que verifica se o PATH está nas environment variables

Se não estiver, chama a função env_insert_new(t_ms *ms, char *new_var), que toma a struct
e a linha inteira para meter no env: ######=#######

A MESMA COISA mas para o PWD:
Se não estiver, chama a função env_insert_new(t_ms *ms, char *new_var), que toma a struct
e a linha inteira para meter no env: ######=#######

*/

/*BASH DEFAULT PATH

PATH=/root/.local/bin:/root/bin:usr/local/bin:/user/bin


BASH REPLACES DEFAULT PWD

*/
/*
int main()
{
    //printf("Hello World");
    char *ptr;
    ptr = getcwd(NULL, 0);
    printf("%s\n", ptr);
    free(ptr);
    return 0;
}
*/
