/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bi_export.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/23 14:33:33 by marvin            #+#    #+#             */
/*   Updated: 2023/08/23 14:33:33 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"



int	env_remove(t_ms *ms, int index)
{
	char	**res;
	int		len;
	int		i;
	int		found;

	len = ft_matrixlen(ms->env);
	res = malloc(len * sizeof(*res));
	if (!res)
		return (0);
	i = 0;
	found = 0;
	while (i < len - 1)
	{
		if (i == index)
		{
			found = 1;
			free(ms->env[i]);
		}
		res[i] = ms->env[i + found];
		i++;
	}
	res[i] = NULL;
	free(ms->env);
	ms->env = res;
	return (1);
}

static int	is_in_env(t_ms *ms, char *str, char len)
{
	int	i;

	i = 0;
	while (ms->env[i])
	{
		if (!ft_strncmp(ms->env[i], str, len))
			return (i);
		i++;
	}
	return (-1);
}

int	unset_check_input(char *arg)
{
	int	i;

	i = 0;
	while (arg[i])
	{
		if (!(ft_isalnum(arg[i]) || arg[i] == '_'))
			return (0);
		i++;
	}
	return (1);
}

int	unset_bi(t_ms *ms, int ac, char **av)
{
	int	env_pos;
	int	i;

	i = 0;
	while (i < ac)
	{
		if (!unset_check_input(av[i]))
		{
			ft_putstr_fd(ms->name, STDERR_FILENO);
			ft_putstr_fd(": unset: `", STDERR_FILENO);
			ft_putstr_fd(av[i], STDERR_FILENO);
			ft_putstr_fd("': not a valid identifier\n", STDERR_FILENO);
			//exit status 1
		}
		else
		{
			env_pos = is_in_env(ms, av[i], ft_strlen(av[i]));
			if (env_pos != -1)
			{
				if (!env_remove(ms, env_pos))
				{
					perror("malloc");
					return (0);
				}
			}
		}
		i++;
	}
	return (1);
}
