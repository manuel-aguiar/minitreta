/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bi_cd.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/23 18:18:17 by marvin            #+#    #+#             */
/*   Updated: 2023/08/23 18:18:17 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*

BUILTINS PRINT THE NAME OF THE SHELL ON ERROR

unset HOME

cd

bash: cd: HOME not set

cd doesn't need PWD or OLDPWD (env variables)

usar chdir, returns -1 on error, error message "No such file or directory"
error code 1


cd hello cenas
bash: cd: too many arguments


*/
