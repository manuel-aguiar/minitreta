/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bi_export.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/23 14:33:33 by marvin            #+#    #+#             */
/*   Updated: 2023/08/23 14:33:33 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*

Export adiciona variáveis ao environment que está guardado na struct MS


*/



int	env_insert_new(t_ms *ms, char *new_var)
{
	char	**res;
	int		len;
	int		i;

	len = ft_matrixlen(ms->env);
	res = malloc((len + 2) * sizeof(*res));
	if (!res)
		return (0);
	i = 0;
	while (i < len + 1)
	{
		if (i == 0)
		{
			res[i] = ft_strdup(new_var);
			if (!res[i])
			{
				free(res);
				perror("malloc");
				return (0);
			}
		}
		else
			res[i] = ms->env[i - 1];
		i++;
	}
	res[i] = NULL;
	free(ms->env);
	ms->env = res;
	return (1);
}

int	is_in_env(t_ms *ms, char *str, char len)
{
	int	i;

	i = 0;
	while (ms->env[i])
	{
		if (!ft_strncmp(ms->env[i], str, len))
			return (i);
		i++;
	}
	return (-1);
}

int	export_check_input(char *arg)
{
	int	i;

	i = 0;
	while (arg[i] && arg[i] != '=')
	{
		if (!(ft_isalnum(arg[i]) || arg[i] == '_'))
			return (0);
		i++;
	}
	return (1);
}

int	export_bi(t_ms *ms, int ac, char **av)
{
	char	**copy;
	char	*equal;
	int		env_pos;
	int		i;

	if (ac == 0)
	{
		if (!ft_charmatdup(&copy, ms->env) ||
		!quicksort_pointers(copy, ft_matrixlen(copy), &env_strcmp))
			return (0);
		i = 0;
		while (copy[i])
			ft_printf_fd(ms->cur_out, "%s\n", copy[i++]);
		ft_free_charmat_null(&copy, &free);
		return (1);
	}
	i = 0;
	while (av[i])
	{
		if (!export_check_input(av[i]))
		{
			ft_putstr_fd(ms->name, STDERR_FILENO);
			ft_putstr_fd(": export: `", STDERR_FILENO);
			ft_putstr_fd(av[i], STDERR_FILENO);
			ft_putstr_fd("': not a valid identifier\n", STDERR_FILENO);
			//exit status 1
		}
		else
		{
			equal = ft_strchr(av[i], '=');
			if (equal)
			{
				env_pos = is_in_env(ms, av[i], (int)(equal - av[i]));
				if (env_pos != -1)
				{
					free(ms->env[env_pos]);
					ms->env[env_pos] = ft_strdup(av[i]);
					if (!ms->env[env_pos])
					{
						perror("malloc");
						exit(EXIT_FAILURE);
					}
				}
				else if (!env_insert_new(ms, av[i]))
				{

					perror("malloc");
					exit(EXIT_FAILURE);
				}
			}
		}
		i++;
	}
	return (1);
}
