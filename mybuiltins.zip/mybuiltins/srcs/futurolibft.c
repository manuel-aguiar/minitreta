/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   futurolibft.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/24 14:49:19 by marvin            #+#    #+#             */
/*   Updated: 2023/08/24 14:49:19 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*

ft_matrixlen - dá o comprimento de um array com pointers lá dentro
				é como um strlen mas para char **, por exemplo.

ft_charmatdup - é como um strdup mas para char ** em vez de só string.
				passas a morada de destino do array como parametro
				a função retorna 1 com sucesso, 0 com erro.
				Em caso de erro, *dest é posto a NULL

*/


int	ft_matrixlen(void *mat)
{
	t_uchar **move;
	int			i;

	if (!mat)
		return (-1);
	move = (t_uchar **)mat;
	i = 0;
	while (move[i])
		i++;
	return (i);
}

int	ft_charmatdup(char ***dest, char **src)
{
	char	**res;
	int		len;
	int		i;

	len = ft_matrixlen(src);
	res = malloc((len + 1) * sizeof(*res));
	if (!res)
		return (0);
	i = 0;
	while (i < len)
	{
		res[i] = ft_strdup(src[i]);
		if (!res[i])
		{
			ft_free_charmat_null(&res, &free);
			*dest = res;
			return (0);
		}
		i++;
	}
	res[i] = NULL;
	*dest = res;
	return (1);
}
