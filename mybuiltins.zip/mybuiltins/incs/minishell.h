/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/01 12:36:48 by marvin            #+#    #+#             */
/*   Updated: 2023/08/24 15:01:08 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H

# define MINISHELL_H

# include <fcntl.h>
# include <stdlib.h>
# include <stdio.h>
# include <unistd.h>
# include <stdio.h>
# include <limits.h>
# include <errno.h>

# include "libft.h"

# define TRUE 1
# define FALSE 0

# define MYNAME "minishell"

typedef struct s_ms		t_ms;

struct s_ms
{
	char		**env;
	char		name[10];
	int			cur_out;
	int			cur_in;
	int			exit_status;

};

int		ft_matrixlen(void *mat);
int		ft_charmatdup(char ***dest, char **src);
void	*quicksort_pointers(void *arr, int size, int (*cmp)(void *, void *));
int		env_strcmp(void *s1, void *s2);


/*bi_export.c*/
int		export_bi(t_ms *ms, int ac, char **av);

/*bi_unset.c*/
int		unset_bi(t_ms *ms, int ac, char **av);

int	ft_matrixlen(void *mat);
int	ft_charmatdup(char ***dest, char **src);
int init_ms(t_ms *ms, char **env);



/*free_all*/
int	free_all(t_ms *ms);

#endif
