
#include "minishell.h"

int free_all(t_ms *ms)
{
	(void)ms;
	return (0);
}

t_redir *init_redir(char *file, int type)
{
    t_redir *redir;
    
    redir = malloc(sizeof(*redir));
    if (!redir)
        return (NULL);
    redir->file = file;
    redir->type = type;
    return (redir);
}

void	destroy_redir(void *og_redir)
{
	t_redir *rdir;

	rdir = *(t_redir **)og_redir;
	ft_free_set_null(&rdir->file);
	ft_free_set_null(og_redir);
}

void	destroy_block(void *og_block)
{
	t_block *block;

	block = *(t_block **)og_block;
	ft_free_set_null(&block->prompt);
	ft_free_set_null(&block->cmd);
	ft_free_charmat_null(&block->cmd_args, free);
	vdmlist_destroy(&block->infiles, destroy_redir);
	vdmlist_destroy(&block->outfiles, destroy_redir);
	vdmlist_destroy(&block->children, destroy_block);
	vdmlist_destroy(&block->big_operators, free);
	ft_free_set_null(og_block);
}

t_block	*init_block(t_ms *ms, t_block *father, char *pmt)
{
	t_block	*new;

	new = malloc(sizeof(*new));
	if (!new)
		return (NULL);
	new->ms = ms;
	new->father = father;
	if (father)
	{
		new->infd = father->infd;
		new->outfd = father->outfd;
		new->prompt = ft_strdup(pmt);
	}
	else
	{
		new->infd = ms->infd;
		new->outfd = ms->outfd;
		new->prompt = ft_strdup(ms->prompt);
	}
	new->cmd = NULL;
	new->cmd_args = NULL;
	new->infiles = NULL;
	new->outfiles = NULL;
	new->children = NULL;
	new->big_operators = NULL;
	return (new);
}

int	destroy_ms(t_ms *ms)
{
	ft_free_charmat_null(&ms->env, free);
	ft_free_set_null(&ms->path);
	ft_free_set_null(&ms->prompt);
	destroy_block(&ms->first);
	return (1);
}

int init_ms(t_ms *ms, char **env)
{
	if (!ft_charmatdup(&ms->env, env))
		return (free_all(ms));
	ft_strlcpy(ms->name, MYNAME, sizeof(ms->name));
	ms->infd = STDIN_FILENO;
	ms->outfd = STDOUT_FILENO;
	return (1);
}