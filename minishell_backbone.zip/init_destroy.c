
#include "minishell.h"

int free_all(t_ms *ms)
{
	(void)ms;
	return (0);
}

t_redir *init_redir(char *file, int type)
{
    t_redir *redir;
    
    redir = malloc(sizeof(*redir));
    if (!redir)
        return (NULL);
    redir->file = file;
    redir->type = type;
    return (redir);
}

void	destroy_redir(void *og_redir)
{
	t_redir *rdir;

	rdir = (t_redir *)og_redir;
	ft_free_set_null(&rdir->file);
	free(og_redir);
}

void	destroy_block(t_block *block)
{
	if (block->son)
	    destroy_block(block->son);
	
	if (block->prompt)
	    ft_free_set_null(&block->prompt);
	
	if (block->father)
	    block->father->son = NULL;
	if (block->io_files)
	    vdmlist_destroy(&block->io_files, destroy_redir);
	if (block->here_doc)
	    ft_free_set_null(&block->child_pids);
	if (block->is_cmd)
	{
	    if (block->cmd)
	        ft_free_set_null(&block->cmd);
	    if (block->cmd_args)
	        ft_free_charmat_null(&block->cmd_args, free);
	    if (block->cmd)
	        ft_free_set_null(&block->cmd);
	}
	else
	{
	    if (block->children)
	        ft_free_charmat_null(&block->children, free);
        if (block->child_pids)
	        ft_free_set_null(&block->child_pids);  
        if (block->op_id)
	        ft_free_set_null(&block->op_id);
	}
}

void	init_block(t_block *new, t_ms *ms, t_block *father, char *pmt)
{
    new->ms = ms;
	new->father = father;
	new->son = NULL;
	if (father)
	{
		new->inherit_in = father->final_in;
		new->inherit_out = father->final_out;
		new->prompt = ft_strdup(pmt);
		new->father->son = new;
	}
	else
	{
		new->inherit_in = ms->infd;
		new->inherit_out = ms->outfd;
		new->prompt = ft_strdup(ms->prompt);
	}
	
	new->children = NULL;
	new->child_pids = NULL;
    new->op_count = 0;
    new->op_id = NULL;
	new->is_cmd = 0;
	
	new->pipefd[0] = -1;
	new->pipefd[1] = -1;
	new->pp_readfd = -1;
	new->status = 0;
	
	new->cmd = NULL;
	new->cmd_args = NULL;
	new->io_files = NULL;
	new->final_in = -1;
	new->final_out = -1;
	new->here_doc = NULL;
	
}

int	destroy_ms(t_ms *ms)
{
	if (ms->env)
	    ft_free_charmat_null(&ms->env, free);
	if (ms->path)
	    ft_free_charmat_null(&ms->path, free);
	if (ms->prompt)
	    ft_free_set_null(&ms->prompt);
	if (ms->first)
	    destroy_block(ms->first);
	return (1);
}

int ms_set_path(t_ms *ms)
{
    int     i;
    
    if (!ms->env)
        return (1);
    i = 0;
    while (ft_strncmp("PATH", ms->env[i], 4))
        i++;
    if (!ms->env[i])
        ms->path = NULL;
    else
    {
        ms->path = ft_split(&ms->env[i][5], ':');
        if (!ms->path)
            return (0);
    }
    return (1);
}

int init_ms(t_ms *ms, char *avzero, char **env)
{
    if (!ft_charmatdup(&ms->env, env))
		return (free_all(ms));
    if (!ms_set_path(ms))
    return (0);
    ms->prompt = NULL;
    ms->name = avzero;
	ms->infd = STDIN_FILENO;
	ms->outfd = STDOUT_FILENO;
	ms->errfd = STDERR_FILENO;
	ms->my_kid = -1;
	return (1);
}