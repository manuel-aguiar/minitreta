#include "minishell.h"

static void	dfs(char *buf, int max, int cur, int *found)
{
	char	c;

	if (cur == max)
		return ;
	if (!*found && *buf && access(buf, F_OK) != 0)
	{
		*found = 1;
		return ;
	}
	if (*found)
		return ;
	else
	{
		c = 'a';
		while (c <= 'z')
		{
			buf[cur] = c;
			dfs(buf, max, cur + 1, found);
			if (*found)
				return ;
			buf[cur] = '\0';
			c++;
		}
	}
}

static int	here_doc_temp(t_block *block)
{
	char	new[256];
	int		found;

	found = 0;
	ft_memset(new, '\0', sizeof(new));
	dfs(new, sizeof(new), 0, &found);
	block->tmp_name = ft_strdup(new);
	//printf("temp name: %s\n", block->tmp_name);
	if (block->tmp_name)
		return (1);
	//printf("name failed\n");
	return (0);
}

static int here_doc_fill(t_block *block, char *eof)
{
	char	*line;

	while (1)
	{
		line = get_next_line(block->ms->infd);
		if (line)
		{
			if (!ft_strncmp(eof, line, ft_strlen(eof)) \
			&& ft_strlen(eof) == ft_strlen(line) - 1)
			{
				ft_free_set_null(&line);
				break ;
			}
			else
				ft_putstr_fd(line, block->final_in);
			ft_free_set_null(&line);
		}
		else
			break ;
	}
	close(block->final_in);
	block->final_in = open(block->tmp_name, O_RDONLY);
	if (block->final_in == -1)
		return (0);                                       // perror("open");
	return (1);    
}


int here_doc(t_block *block, char *eof)
{
    
    if (!here_doc_temp(block))
        return (0);                 // malloc failed perror(malloc) guarda exit status 

    block->final_in = open(block->tmp_name, O_CREAT | O_TRUNC | O_RDWR, 0644);
    if (block->final_in == -1)
        return (0);                //open failed, perror(open) guarda exit status
    if (!here_doc_fill(block, eof))
        return (0);                 // malloc failed perror(malloc) guarda exit status
    return (1);
}


int manage_infiles(t_block *block)
{
    t_vdmnode *cur;
    
    if (block->father)
        block->final_in = block->infd;
    else
        block->final_in = block->ms->infd;
    if (!block->infiles)
        return (1);
    cur = block->infiles->head;
    while (cur)
    {
        close_in_fds(block);
        if (block->tmp_name)
        {
            unlink(block->tmp_name);
            ft_free_set_null(&block->tmp_name);
        }
        if (((t_redir *)cur->data)->type == RE_HEREDOC)
        {
           // printf("must be heredoc\n");
            here_doc(block, ((t_redir *)cur->data)->file);     // (if (!here_doc open failed, perror(open) guarda exit status
        }
        else
        {
            block->final_in = open(((t_redir *)cur->data)->file, O_RDWR);
            if (block->final_in == -1)
                break ;                              //open failed, perror(open) guarda exit status (no return, list memleak!!!)
        }
        cur = cur->next;
    }
    vdmlist_destroy(&block->infiles, destroy_redir);
    return (1);
}

int manage_outfiles(t_block *block)
{
    t_vdmnode *cur;
    
    if (block->father)
        block->final_out = block->outfd;
    else
        block->final_out = block->ms->outfd;
    if (!block->outfiles)
        return (1);
    cur = block->outfiles->head;
    while (cur)
    {
        close_out_fds(block);
        if (((t_redir *)cur->data)->type == RE_TRUNC)
            block->final_out = open(((t_redir *)cur->data)->file, O_CREAT | O_RDWR | O_TRUNC, 0644);
        else
            block->final_out = open(((t_redir *)cur->data)->file, O_CREAT | O_RDWR | O_APPEND, 0644);
        if (block->final_out == -1)
            break ;                              //open failed, perror(open) guarda exit status (no return, list memleak!!!)
        cur = cur->next;
    }
    vdmlist_destroy(&block->outfiles, destroy_redir);
    return (1);
}





