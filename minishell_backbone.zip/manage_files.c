#include "minishell.h"

int manage_io_expansion(t_block *block)
{
    char *temp;
    char *fail_return;
    
    fail_return = NULL;
    block->prompt_copy = ((t_redir *)block->io_files->head->data)->file;
    if (block->prompt_copy[0] != '\'')
        expand_dollars(block, block->ms);
    if (block->prompt_copy[0] != '\'' \
    && block->prompt_copy[0] != '"')
        expand_wildcards(block, &fail_return);
    if (fail_return)
    {
        dprintf(block->ms->errfd, "minishell: %s: ambiguous redirection\n", fail_return);
        free(fail_return);
        ((t_redir *)block->io_files->head->data)->file = block->prompt_copy;
        return (0);
    }
    if (block->prompt_copy[0] == '\'' \
    || block->prompt_copy[0] == '"')
    {
        block->prompt_copy[ft_strlen(block->prompt_copy) - 1] = '\0';
        temp = ft_strdup(&block->prompt_copy[1]);
        if (!temp)
            return (0);
        free(block->prompt_copy);
        block->prompt_copy = temp;
    }
    ((t_redir *)block->io_files->head->data)->file = block->prompt_copy;
    return (1);
}


static void	dfs(char *buf, int max, int cur, int *found)
{
	char	c;

	if (cur == max)
		return ;
	if (!*found && *buf && access(buf, F_OK) != 0)
	{
		*found = 1;
		return ;
	}
	if (*found)
		return ;
	else
	{
		c = 'a';
		while (c <= 'z')
		{
			buf[cur] = c;
			dfs(buf, max, cur + 1, found);
			if (*found)
				return ;
			buf[cur] = '\0';
			c++;
		}
	}
}

static int	here_doc_temp(t_block *block)
{
	char	new[256];
	int		found;

	found = 0;
	ft_memset(new, '\0', sizeof(new));
	dfs(new, sizeof(new), 0, &found);
	block->tmp_name = ft_strdup(new);
	//printf("temp name: %s\n", block->tmp_name);
	if (block->tmp_name)
		return (1);
	//printf("name failed\n");
	return (0);
}

static int here_doc_fill(t_block *block, char *eof)
{
	char	*line;

	while (1)
	{
		line = get_next_line(block->ms->infd);
		if (line)
		{
			if (!ft_strncmp(eof, line, ft_strlen(eof)) \
			&& ft_strlen(eof) == ft_strlen(line) - 1)
			{
				ft_free_set_null(&line);
				break ;
			}
			else
				ft_putstr_fd(line, block->final_in);
			ft_free_set_null(&line);
		}
		else
			break ;
	}
	close(block->final_in);
	block->final_in = open(block->tmp_name, O_RDONLY);
	if (block->final_in == -1)
		return (0);                                       // perror("open");
	return (1);    
}


int here_doc(t_block *block, char *eof)
{
    
    if (!here_doc_temp(block))
        return (0);                 // malloc failed perror(malloc) guarda exit status 

    block->final_in = open(block->tmp_name, O_CREAT | O_TRUNC | O_RDWR, 0644);
    if (block->final_in == -1)
        return (perror_msg_func(block, block->tmp_name, CODE_OPEN, 1));                 //open failed, perror(open) guarda exit status
    if (!here_doc_fill(block, eof))
        return (perror_msg_func(block, block->tmp_name, CODE_OPEN, 1));                  // malloc failed perror(malloc) guarda exit status
    return (1);
}


int manage_infile(t_block *block)
{
    t_redir *redir;
    
    redir = (t_redir *)block->io_files->head->data;
    close_in_fds(block);
    if (block->tmp_name)
    {
        unlink(block->tmp_name);
        ft_free_set_null(&block->tmp_name);
    }
    if (redir->type == RE_HEREDOC)
    {
        if(!here_doc(block, redir->file))
            return (0);
    }
    else
    {
        block->final_in = open(redir->file, O_RDWR);
        if (block->final_in == -1)
             return (perror_msg_func(block, redir->file, CODE_OPEN, 1));                              //open failed, perror(open) guarda exit status (no return, list memleak!!!)
    }
    vdmlist_del_head(block->io_files, destroy_redir);
    return (1);
}

int manage_outfile(t_block *block)
{
    t_redir *redir;
    
    redir = (t_redir *)block->io_files->head->data;
    close_out_fds(block);
    if (redir->type == RE_TRUNC)
        block->final_out = open(redir->file, O_CREAT | O_RDWR | O_TRUNC, 0644);
    else
        block->final_out = open(redir->file, O_CREAT | O_RDWR | O_APPEND, 0644);
    if (block->final_out == -1)
        return (perror_msg_func(block, redir->file, CODE_OPEN, 1));                              //open failed, perror(open) guarda exit status (no return, list memleak!!!)
    vdmlist_del_head(block->io_files, destroy_redir);
    return (1);
}

int manage_io_files(t_block *block)
{
    int         type;
    int         success;
    
    block->final_out = block->inherit_out;
    if (block->father \
    && block->my_id < block->father->op_count \
    && block->father->op_id \
    && block->father->op_id[block->my_id] == OP_PIPE)
        block->final_out = block->father->pipefd[1];
    block->final_in = block->inherit_in;
    if (block->my_id > 0 \
    && block->father \
    && block->father->op_id \
    && block->father->op_id[block->my_id - 1] == OP_PIPE)
        block->final_in = block->father->pp_readfd;
    if (!block->io_files)
        return (1);
    success = 1;
    while (block->io_files->head && success)
    {
        type = ((t_redir *)block->io_files->head->data)->type;
        success = manage_io_expansion(block);
        if (!success)
            break ;
        if (type == RE_TRUNC || type == RE_APPEND)
            success = manage_outfile(block);
        else
            success = manage_infile(block);
    }
    vdmlist_destroy(&block->io_files, destroy_redir);
    return (success);
}





