/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 09:52:17 by marvin            #+#    #+#             */
/*   Updated: 2023/08/25 09:52:17 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

typedef struct s_cmd
{
    char        *full_path;
    char        **cmd_args;
    t_vdmlist   *infiles;
    t_vdmlist   *outfiles;
    
    char        **temp;
    int         args_len;
    int         split_len;
}   t_cmd;

int free_cmd(t_cmd *cmd)
{
    ft_free_set_null(&cmd->full_path);
    ft_free_charmat_null(&cmd->cmd_args, free);
    vdmlist_destroy(&cmd->infiles, destroy_redir);
    vdmlist_destroy(&cmd->outfiles, destroy_redir);
}

void    print_split(char **split)
{
    int i;
    
    if (!split)
        return ;
    i = 0;
    while (split[i])
        printf("%s\n", split[i++]);
    
}

/*if (temp[i] && temp[i][0] == '<')
        {
            if (temp[i][1] == '<')
                vdmlist_in_head(cmd->infiles, init_redir(temp[i + 1], RE_HEREDOC));
            else
                vdmlist_in_head(cmd->infiles, init_redir(temp[i + 1], RE_INFILE));
            ft_free_set_null(&temp[i - 1]);
            temp[i] = NULL;
            rd_num++;
        }
        else if (temp[i] && temp[i][0] == '>')
        {
            if (temp[i][1] == '>')
                vdmlist_in_head(cmd->outfiles, init_redir(temp[i++ + 1], RE_APPEND));
            else
                vdmlist_in_head(cmd->outfiles, init_redir(temp[i + 1], RE_TRUNC));
            ft_free_set_null(&temp[i - 1]);
            temp[i] = NULL;
            rd_num++;
        }
        i++;*/

int setup_cmd(t_cmd *cmd, char *prompt)
{
    char    **temp;
    char    **cmd_args;
    int     args_len;
    int     split_len;
    int     i;
    int     j;
    int     type;
    
    cmd->full_path = NULL;
    cmd->cmd_args = NULL;
    cmd->infiles = vdmlist_new();
    cmd->outfiles = vdmlist_new();
    temp = ft_split(prompt, ' ');
    if (!temp)
        return (0);
    split_len = ft_matrixlen(temp);
    args_len = 0;
    i = 0;
    while (i < split_len)
    {
        /*if (temp[i] && temp[i][0] == '<')
        {
            if (temp[i][1] == '<')
                vdmlist_in_head(cmd->infiles, init_redir(temp[i + 1], RE_HEREDOC));
            else
                vdmlist_in_head(cmd->infiles, init_redir(temp[i + 1], RE_INFILE));
            ft_free_set_null(&temp[i - 1]);
            temp[i] = NULL;
            rd_num++;
        }
        else if (temp[i] && temp[i][0] == '>')
        {
            if (temp[i][1] == '>')
                vdmlist_in_head(cmd->outfiles, init_redir(temp[i++ + 1], RE_APPEND));
            else
                vdmlist_in_head(cmd->outfiles, init_redir(temp[i + 1], RE_TRUNC));
            ft_free_set_null(&temp[i - 1]);
            temp[i] = NULL;
            rd_num++;
        }
        i++;*/
    }
    cmd_args = malloc(sizeof(*cmd_args) * (split_len - rd_num * 2 + 1));
    if (!cmd_args)
        return (0);
    j = 0;
    i = 0;
    while (i < split_len)
    {
        if (temp[i])
            cmd_args[j++] = temp[i];
        i++;
    }
    cmd_args[j] = NULL;
    ft_free_set_null(&temp);
    if (cmd->infiles->len)
        vdmlist_destroy(&cmd->infiles, destroy_redir);
    if (cmd->outfiles->len)
        vdmlist_destroy(&cmd->outfiles, destroy_redir);
    cmd->cmd_args = cmd_args;
    return (1);
}


int main(int ac, char **av, char **env)
{
	t_ms	ms;
	t_cmd   cmd;
    
    (void)ac;
    (void)av;
	if (!init_ms(&ms, env))
		return (0);
	get_prompt(&ms);
	
	char *ptr;
	
	ptr = ms.prompt;
	
	setup_cmd(&cmd, &ptr);
	
	printf("cmd args: ");
	int i = 0;
	while (cmd.cmd_args[i])
	    printf("%s ", cmd.cmd_args[i++]);
	printf("\n");

	free_cmd(&cmd);
	ms.first = init_block(&ms, NULL, NULL);
	destroy_ms(&ms);
	return (0);
}

/*

here_doc, mesmo se nao for o infile definitivo tem de deixar escrever
se o infile falhar, o comando nao executa, erro tipo 1

*/

