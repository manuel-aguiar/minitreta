/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 09:52:17 by marvin            #+#    #+#             */
/*   Updated: 2023/08/25 09:52:17 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int main(int ac, char **av, char **env)
{
	t_ms	ms;
	t_cmd   cmd;
	t_split split;
    
    (void)ac;
    (void)av;
	if (!init_ms(&ms, env))
		return (0);
	while (1)
	{
    	if (get_prompt(&ms))
    	{
    	    printf("prompt: %s\n", ms.prompt);
        	split.prompt = ft_strdup(ms.prompt);
        	split_prompt(&split);
        	print_split(&split);
        	free_split_prompt(&split);
        	/*setup_cmd(&cmd, ms.prompt);
            //print_cmd(&cmd);
        	ms.first = init_block(&ms, NULL, NULL);
        	
        	dump_cmd_to_block(ms.first, &cmd);
        	if (ms.first->infiles)
        	    manage_infiles(ms.first);
        	if (ms.first->outfiles)
        	    manage_outfiles(ms.first);*/
    	}
	}
	destroy_ms(&ms);
	printf("\nexiting\n");
	return (0);
}

/*

se o infile falhar, o comando nao executa, erro tipo 1

*/

