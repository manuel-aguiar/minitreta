/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 09:52:17 by marvin            #+#    #+#             */
/*   Updated: 2023/08/25 09:52:17 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"



/*
    execute
    This function prepares the command for execution.
    If redirections have a problem (ambiguous/non existent), close the remaining file descriptors
    and exit.
    
    If there is no command (the prompt is made of only redirections, totally legal)
    just close the file descriptors and exit.
    
    Otherwise, call process_execution: responsible for fork and execve.

*/

int execute(t_block *block)
{
    setup_cmd(block);
    if(!manage_io_files(block))
    {
        close_in_fds(block);
        close_out_fds(block);
        return (0);
    }
    if (block->cmd)
        process_execution(block);
    else
    {
        close_in_fds(block);
        close_out_fds(block);
    }
    return (1);
}

/*

    pipes_and_conditionals
    Sets up the commands based on the big 3 operators: && || and |.
        -   Saves the read end of the previous pipe, if a pipe was open
            the next operator may be a pipe as well: pipe will overwrite
            the previous file descriptors
        -   Opens a new pipe if the current command will write too a pipe;
        -   In case of && or ||, waits for the previous commands to arrive
            in order to determine their exit status and decide wether
            the following command will execute or not;

*/

int pipes_and_conditionals(t_block *block, int index)
{
    int i;
    
    if (index > 0 && block->op_id[index - 1] == OP_PIPE)
        block->pp_readfd = block->pipefd[0];
    if (index < block->op_count && block->op_id[index] == OP_PIPE)
    {
        if (pipe(block->pipefd) == -1)
            return (0);                                                         //must give an error message for failure to open a pipe
    }
    if (index > 0 && index <= block->op_count \
    && (block->op_id[index - 1] == OP_AND || block->op_id[index - 1] == OP_OR))
    {
        //dprintf(2, "conditionals \n");
        i = -1;
        while (++i < index - 1)
        {
            if (block->child_pids[i] != 0)
            {
                //dprintf(2, "waiting\n");
                waitpid(block->child_pids[i], &block->ms->exit_status, 0);
                
                block->child_pids[i] = 0;
            }
        }
        //dprintf(2, "exit status: %d op_id %d\n", block->ms->exit_status, block->op_id[index - 1]);
        if ((block->op_id[index - 1] == OP_AND && block->ms->exit_status != 0) \
        || (block->op_id[index - 1] == OP_OR && block->ms->exit_status == 0))
            return (0);
    }
    return (1);
}


int execution_tree(t_ms *ms, t_block *father, char *pmt, int my_id)
{
    t_block     *block;
    int         i;
    
    block = init_block(ms, father, pmt, my_id);   //protect
    //printf("blocking prompt: [%s]\n", pmt);
    split_prompt(block);                         //protect
    //print_split(block);
    if(!manage_io_files(block))
    {
        destroy_block(&block);
        return (1);
    }
    if (block->is_cmd)
        execute(block);
    else
    {
        i = -1;
        while (block->children[++i])
        {
            
            if (block->op_id && pipes_and_conditionals(block, i))
            {
                
                execution_tree(ms, block, block->children[i], i);
                /*if (i > 0 && block->op_id[i - 1] == OP_PIPE)
                {
                    
                    dprintf(2, "BOSS closed piperead %d, closed well? %d\n", block->pp_readfd, close(block->pp_readfd));
                }
                if (i < block->op_count && block->op_id[i] == OP_PIPE)
                {
                    
                    dprintf(2, "BOSS closed pipe-write %d, closed well? %d\n", block->pipefd[1], close(block->pipefd[1]));
                }*/
            }
        }
        i = -1;
        while (++i < block->op_count + 1)
        {
            if (block->child_pids[i] != 0)
            {
                
                waitpid(block->child_pids[i], &block->ms->exit_status, 0);
                if (WIFEXITED(block->ms->exit_status))
                    block->ms->exit_status = WEXITSTATUS(block->ms->exit_status);
                block->child_pids[i] = 0;
            }
        }
        close_in_fds(block);
        close_out_fds(block);
    }
    destroy_block(&block);
    return (1);
}

int main(int ac, char **av, char **env)
{
	t_ms	ms;
    
    (void)ac;
    (void)av;
    
    
    
	if (!init_ms(&ms, env))
		return (0);
	while (1)
	{
    	if (get_prompt(&ms))
    	{
    	    //dprintf(2, "prompt is [%s]\n", ms.prompt);
        	execution_tree(&ms, NULL, ms.prompt, 0);
        	if (ms.my_kid != -1)
        	{
        	    waitpid(ms.my_kid, &ms.exit_status, 0);
        	    if (WIFEXITED(ms.exit_status))
        	        ms.exit_status = WEXITSTATUS(ms.exit_status);
        	    ms.my_kid = -1;
        	}
    	}
    	
    	//printf("stuck\n");
	}
	destroy_ms(&ms);
	
	return (0);
}

/*

se o infile falhar, o comando nao executa, erro tipo 1

ERROS: 
    ||) não dá syntax error

    redirecções nao sao separadas entre in e outfd
    são analisadas por ordem de chegada da esquerda para a direita
    se uma falha (ficheiro na existe) as outras nao abrem





*/

