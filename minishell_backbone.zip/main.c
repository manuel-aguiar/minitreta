/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 09:52:17 by marvin            #+#    #+#             */
/*   Updated: 2023/08/25 09:52:17 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void    close_in_fds(t_block *block)
{
    if (block->father)
    {
        if (block->final_in != block->father->final_in)
            close(block->final_in);
    }
    else
    {
        if (block->final_in != block->ms->infd)
            close(block->final_in);
    }
}

void    close_out_fds(t_block *block)
{
    if (block->father)
    {
        if (block->final_out != block->father->final_out)
            close(block->final_out);
    }
    else
    {
        if (block->final_out != block->ms->outfd)
            close(block->final_out);
    }    
}

int execute(t_block *block)
{
    //printf("executing: [%s]\n", block->cmd);
    //manage_infiles(block);
    //printf("infiles done ms in %d, block in %d\n", block->ms->infd, block->final_in);
    //manage_outfiles(block);
    //printf("outfiles done ms out %d, block out %d\n", block->ms->outfd, block->final_out);
    process_execution(block);
    
    return (1);
}

int execution_tree(t_ms *ms, t_block *father, char *pmt, int my_id)
{
    t_block     *block;
    int         i;
    
    block = init_block(ms, father, pmt, my_id);   //protect
    split_prompt(block);                         //protect
    manage_infiles(block);
    manage_outfiles(block);
    if (block->is_cmd)
    {
        setup_cmd(block);
        execute(block);
    }
    else
    {
        i = -1;
        while (block->children[++i])
            execution_tree(ms, block, block->children[i], i);
        i = -1;
        while (++i < block->op_count + 1)
        {
            if (block->child_pids[i] != 0)
            {
                waitpid(block->child_pids[i], &block->status, 0);
                block->child_pids[i] = 0;
            }
        }
        close_in_fds(block);
        close_out_fds(block);
    }
    destroy_block(&block);
    return (1);
}

int main(int ac, char **av, char **env)
{
	t_ms	ms;
    t_block block;
    
    (void)ac;
    (void)av;
	if (!init_ms(&ms, env))
		return (0);
	while (1)
	{
    	if (get_prompt(&ms))
    	{
    	    
        	execution_tree(&ms, NULL, ms.prompt, 0);
        	if (ms.my_kid != -1)
        	{
        	    waitpid(ms.my_kid, &ms.exit_status, 0);
        	    ms.my_kid = -1;
        	}
    	}
    	//printf("stuck\n");
	}
	destroy_ms(&ms);
	printf("\nexiting\n");
	return (0);
}

/*

se o infile falhar, o comando nao executa, erro tipo 1

*/

