/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 09:52:17 by marvin            #+#    #+#             */
/*   Updated: 2023/08/25 09:52:17 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void    close_in_fds(t_block *block)
{
    if (block->final_in != block->inherit_in)
        close(block->final_in);
}

void    close_out_fds(t_block *block)
{
    if (block->final_out != block->inherit_out)
        close(block->final_out);
}

int execute(t_block *block)
{
    setup_cmd(block);
    printf("executing: [%s]\n", block->cmd);
    manage_infiles(block);
    printf("infiles done ms in %d, block in %d\n", block->ms->infd, block->final_in);
    manage_outfiles(block);
    printf("outfiles done ms out %d, block out %d\n", block->ms->outfd, block->final_out);
    process_execution(block);
    
    return (1);
}

int pipes_and_conditionals(t_block *block, int index)
{
    int i;
    
    if (index > 0 && block->op_id[index - 1] == OP_PIPE)
        block->pp_readfd = block->pipefd[0];
    if (index > 0 && index <= block->op_count)
    {
        //dprintf(2, " op_id %d\n", block->op_id[index - 1]);
        if (index < block->op_count && block->op_id[index] == OP_PIPE)
            pipe(block->pipefd);          //unprotected
        else
        {
            //dprintf(2, "conditionals \n");
            i = -1;
            while (++i < index - 1)
            {
                if (block->child_pids[i] != 0)
                {
                    waitpid(block->child_pids[i], &block->ms->exit_status, 0);
                    block->child_pids[i] = 0;
                }
            }
            //dprintf(2, "exit status of prev: %d\n", block->ms->exit_status);
            if ((block->op_id[index - 1] == OP_AND && block->ms->exit_status != 0) \
            || (block->op_id[index - 1] == OP_OR && block->ms->exit_status == 0))
                return (0);
        }
    }
    return (1);
}


int execution_tree(t_ms *ms, t_block *father, char *pmt, int my_id)
{
    t_block     *block;
    int         i;
    
    block = init_block(ms, father, pmt, my_id);   //protect
    printf("blocking prompt:%s\n", pmt);
    split_prompt(block);                         //protect
    print_split(block);
    manage_infiles(block);
    manage_outfiles(block);
    if (block->is_cmd)
        execute(block);
    else
    {
        i = -1;
        while (block->children[++i])
        {
            
            if (block->op_id && pipes_and_conditionals(block, i))
            {
                
                execution_tree(ms, block, block->children[i], i);
                if (i > 0 && block->op_id[i - 1] == OP_PIPE)
                    close(block->pp_readfd);        //unprotected
                if (i < block->op_count && block->op_id[i] == OP_PIPE)
                    close(block->pipefd[1]);        //unprotected
            }
            else
                break ;
        }
        i = -1;
        while (++i < block->op_count + 1)
        {
            if (block->child_pids[i] != 0)
            {
                waitpid(block->child_pids[i], &block->ms->exit_status, 0);
                block->child_pids[i] = 0;
            }
        }
        close_in_fds(block);
        close_out_fds(block);
    }
    if (block->father)
        block->father->status = block->ms->exit_status;
    destroy_block(&block);
    return (1);
}

int main(int ac, char **av, char **env)
{
	t_ms	ms;
    t_block block;
    
    (void)ac;
    (void)av;
	if (!init_ms(&ms, env))
		return (0);
	while (1)
	{
    	if (get_prompt(&ms))
    	{
    	    
        	execution_tree(&ms, NULL, ms.prompt, 0);
        	if (ms.my_kid != -1)
        	{
        	    waitpid(ms.my_kid, &ms.exit_status, 0);
        	    ms.my_kid = -1;
        	}
    	}
    	//printf("stuck\n");
	}
	destroy_ms(&ms);
	printf("\nexiting\n");
	return (0);
}

/*

se o infile falhar, o comando nao executa, erro tipo 1

*/

