#include "minishell.h"


void    void_putstr(void *str)
{
    char *mine;
    
    mine = (char *)str;
    write(1, mine, ft_strlen(mine));
    printf("\n");
}

char    *triple_join(char *first, char *second, char *third)
{
    int     i;
    char    *new;
    
    new = malloc((ft_strlen(first) + ft_strlen(second) + ft_strlen(third) + 1) * sizeof(*first));
    if (!new)
        return (NULL);
    i = 0;
    while (*first)
        new[i++] = *first++;
    while (*second)
        new[i++] = *second++;
    while (*third)
        new[i++] = *third++;
    new[i] = '\0';
    return (new);
}

void file_list(t_vdmlist *files, char *path, int cur_lvl, int max_lvl)
{
    struct dirent   *entry;
    DIR             *dir;
    char            *filename;
    
    dir = opendir(path);
    if (!dir)
        return ;                                     //perror
    while (1)
    {
        entry = readdir(dir);
        if (!entry)
            break ;
        if (ft_strncmp(entry->d_name, ".", 1) \
        && ft_strncmp(entry->d_name, "..", 2))
        {
            if (!ft_strncmp(path, ".", 1))
                filename = ft_strdup(entry->d_name);
            else
                filename = triple_join(path, "/", entry->d_name);
            if (entry->d_type == DT_REG)
                vdmlist_in_tail(files, filename);
            if (entry->d_type == DT_DIR)
            {
                vdmlist_in_tail(files, ft_strdup(filename));
                if (cur_lvl + 1 <= max_lvl)
                    file_list(files, filename, cur_lvl + 1, max_lvl);
                free(filename);
            }
        }
    }
    closedir(dir);
}


int wildcard_fit(void *file, void *patterns)
{
    char    *name;
    char    **sub_pats;
    char    *cur_pos;
    int     cur_len;
    int     pat_len;
    int     i;
    
    name = (char *)file;
    sub_pats = (char **)patterns;
    cur_pos = name;
    cur_len = ft_strlen(cur_pos);
    i = 0;
    while (sub_pats[i])
    {
        cur_pos = ft_strnstr(cur_pos, sub_pats[i], cur_len);
        if (cur_pos)
        {
            pat_len = ft_strlen(sub_pats[i]);
            cur_pos += (sizeof(*cur_pos) * pat_len);
            cur_len -= pat_len;
        }
        i++;
    }
    if (cur_pos)
        return (1);
    return (0);
}


char    **list_to_array(t_vdmlist *list)
{
    char        **split;
    int         len;
    int         i;
    t_vdmnode   *cur;
    
    if (!list)
        return (NULL);
    len = list->len;
    split = malloc(sizeof(*split) * (len + 1));
    if (!split)
        return (NULL);
    i = 0;
    cur = list->head;
    while (i < len)
    {
        split[i++] = (char *)cur->data;
        cur = cur->next;
    }
    return (split);
}

char    *split_join(char **split, char *sep)
{
    int     len;
    int     i;
    int     j;
    int     k;
    char    *join;
    
    i = 0;
    len = 0;
    while (split[i])
        len += ft_strlen(split[i++]);
    len += (ft_strlen(sep) * (i - 1));
    join = malloc(sizeof(*join) * (len + 1));
    if (!join)
        return (NULL);
    k = 0;
    i = 0;
    while (split[i])
    {
        j = 0;
        while (split[i][j])
            join[k++] = split[i][j++];
        j = 0;
        if (split[i + 1])
            while (sep[j])
                join[k++] = sep[j++];
        i++;
    }
    join[k] = '\0';
    return (join);
}



int count_chars(char *str, char c)
{
    int i;
    int count;
    
    i = 0;
    while (str[i])
    {
        if (str[i] == c)
            count++;
        i++;
    }
    return (count);
}

char     *wildcard(char *pattern)
{
    int         i;
    int         depth;
    int         sub_count;
    char        **sub_pat;
    t_vdmlist   *files;
    char        **split;
    char        *join;
    
    depth = count_chars(pattern, '/');
    sub_pat = ft_split_count(pattern, " *", &sub_count);
    

    

    
    
    
    
    if (!sub_pat)
        return (NULL);
    files = vdmlist_new();
    if (!files)
        return (NULL);
    file_list(files, ".", 0, depth);
    
   /* 
    t_vdmnode *cur;
    
    cur = files->head;
    while (cur)
    {
        printf(" file [%s], fits? %d\n", (char *)cur->data, wildcard_fit(cur->data, sub_pat));
        cur = cur->next;
    }*/
    
    
    vdmlist_remove_if(files, sub_pat, wildcard_fit, free);
    
    vdmlist_head_print(files, void_putstr);
    
    
    ft_free_charmat_null(&sub_pat, free);
    //split = list_to_array(files);
    vdmlist_destroy(&files, NULL);
    //join = split_join(split, " ");
    //ft_free_charmat_null(&split, free);
    //printf("the winners are: %s\n", join);
    //free(join);
    return (NULL);
}