#include "minishell.h"

int free_cmd(t_cmd *cmd)
{
    if (cmd->full_path)
        ft_free_set_null(&cmd->full_path);
    if (cmd->cmd_args)
        ft_free_charmat_null(&cmd->cmd_args, free);
    if (cmd->infiles)
        vdmlist_destroy(&cmd->infiles, destroy_redir);
    if (cmd->outfiles)
        vdmlist_destroy(&cmd->outfiles, destroy_redir);
    if (cmd->temp)
        ft_free_sizemat_null(&cmd->temp, cmd->split_len, free);
    return (1);
}

int init_cmd(t_cmd *cmd)
{
    cmd->full_path = NULL;
    cmd->cmd_args = NULL;
    cmd->infiles = NULL;
    cmd->outfiles = NULL;
    cmd->temp = NULL;
    cmd->args_len = 0;
    cmd->split_len = 0;
    return (1);
}

int get_outfiles(t_cmd *cmd, int *i)
{
    int     type;
    int     cur;
    int     c;
    char    *file;
    
    cur = *i;
    c = 1;
    if (!cmd->outfiles)
        cmd->outfiles = vdmlist_new();
    if (cmd->temp[cur][c] == '>')
    {
        type = RE_APPEND;
        c++;
    }
    else
        type = RE_TRUNC;
    if (cmd->temp[cur][c])
        vdmlist_in_tail(cmd->outfiles, init_redir(ft_strdup(&cmd->temp[cur][c]), type));
    else
    {
        vdmlist_in_tail(cmd->outfiles, init_redir(cmd->temp[cur + 1], type));
        cmd->temp[cur + 1] = NULL;
        *i += 1;
    }
    ft_free_set_null(&cmd->temp[cur]);
    *i += 1;
    return (1);
}

int get_infiles(t_cmd *cmd, int *i)
{
    int     type;
    int     cur;
    int     c;
    char    *file;
    
    cur = *i;
    c = 1;
    if (!cmd->infiles)
        cmd->infiles = vdmlist_new();
    if (cmd->temp[cur][c] == '<')
    {
        type = RE_HEREDOC;
        c++;
    }
    else
        type = RE_INFILE;
    if (cmd->temp[cur][c])
        vdmlist_in_tail(cmd->infiles, init_redir(ft_strdup(&cmd->temp[cur][c]), type));
    else
    {
        vdmlist_in_tail(cmd->infiles, init_redir(cmd->temp[cur + 1], type));
        cmd->temp[cur + 1] = NULL;
        *i += 1;
    }
    ft_free_set_null(&cmd->temp[cur]);
    *i += 1;
    return (1);
}

int get_cmd_args(t_cmd *cmd)
{
    int i;
    int len;
    
    cmd->cmd_args = malloc(sizeof(*cmd->cmd_args) * (cmd->args_len + 1));
    if (!cmd->cmd_args)
        return (0);
    i = 0;
    len = 0;
    while (i < cmd->split_len)
    {
        if (cmd->temp[i])
            cmd->cmd_args[len++] = cmd->temp[i];
        i++;
    }
    cmd->cmd_args[len] = NULL;
    ft_free_set_null(&cmd->temp);
    return (1);
}

int setup_cmd(t_cmd *cmd, char *prompt)
{
    int i;
    
    init_cmd(cmd);
    cmd->temp = ft_split_count(prompt, " ", &cmd->split_len);
    i = 0;
    while (i < cmd->split_len)
    {
        if (cmd->temp[i][0] == '<')
            get_infiles(cmd, &i);
        else if (cmd->temp[i][0] == '>')
            get_outfiles(cmd, &i);
        else
        {
            i++;
            cmd->args_len++;
        }
    }
    get_cmd_args(cmd);
    return (1);
}

void    print_cmd(t_cmd *cmd)
{
    printf("\ncommand args: \n");
    int i;
    if (cmd->cmd_args)
    {
        i = 0;
        while (cmd->cmd_args[i])
            printf("%s\n", cmd->cmd_args[i++]);
    }
    printf("\ninfiles: \n");
    if (cmd->infiles)
    {
        t_vdmnode *cur;
        t_redir *redir;
        cur = cmd->infiles->head;
        while (cur)
        {
            redir = (t_redir *)cur->data;
            printf("type %d, file %s\n", redir->type, redir->file);
            cur = cur->next;
        }
    }
    printf("\noutfiles: \n");
    if (cmd->outfiles)
    {
        t_vdmnode *cur;
        t_redir *redir;
        cur = cmd->outfiles->head;
        while (cur)
        {
            redir = (t_redir *)cur->data;
            printf("type %d, file %s\n", redir->type, redir->file);
            cur = cur->next;
        }
    }
    printf("\n\n");
}

int dump_cmd_to_block(t_block *block, t_cmd *cmd)
{
    if (!block || !cmd)
        return (0);
    block->cmd_args = cmd->cmd_args;
    block->infiles = cmd->infiles;
    block->outfiles = cmd->outfiles;
    return (1);
}

