#include "minishell.h"

int free_cmd(t_block *block)
{
    if (block->cmd)
        ft_free_set_null(&block->cmd);
    if (block->cmd_args)
        ft_free_charmat_null(&block->cmd_args, free);
    if (block->infiles)
        vdmlist_destroy(&block->infiles, destroy_redir);
    if (block->outfiles)
        vdmlist_destroy(&block->outfiles, destroy_redir);
    if (block->help_cmd)
        ft_free_sizemat_null(&block->help_cmd, block->split_len, free);
    return (1);
}

int init_cmd(t_block *block)
{
    block->cmd = NULL;
    block->cmd_args = NULL;
    block->infiles = NULL;
    block->outfiles = NULL;
    block->help_cmd = NULL;
    block->args_len = 0;
    block->split_len = 0;
    return (1);
}

int get_outfiles(t_block *block, int *i)
{
    int     type;
    int     cur;
    int     c;
    char    *file;
    
    cur = *i;
    c = 1;
    if (!block->outfiles)
        block->outfiles = vdmlist_new();
    if (block->help_cmd[cur][c] == '>')
    {
        type = RE_APPEND;
        c++;
    }
    else
        type = RE_TRUNC;
    if (block->help_cmd[cur][c])
        vdmlist_in_tail(block->outfiles, init_redir(ft_strdup(&block->help_cmd[cur][c]), type));
    else
    {
        vdmlist_in_tail(block->outfiles, init_redir(block->help_cmd[cur + 1], type));
        block->help_cmd[cur + 1] = NULL;
        *i += 1;
    }
    ft_free_set_null(&block->help_cmd[cur]);
    *i += 1;
    return (1);
}

int get_infiles(t_block *block, int *i)
{
    int     type;
    int     cur;
    int     c;
    char    *file;
    
    cur = *i;
    c = 1;
    if (!block->infiles)
        block->infiles = vdmlist_new();
    if (block->help_cmd[cur][c] == '<')
    {
        type = RE_HEREDOC;
        c++;
    }
    else
        type = RE_INFILE;
    if (block->help_cmd[cur][c])
        vdmlist_in_tail(block->infiles, init_redir(ft_strdup(&block->help_cmd[cur][c]), type));
    else
    {
        vdmlist_in_tail(block->infiles, init_redir(block->help_cmd[cur + 1], type));
        block->help_cmd[cur + 1] = NULL;
        *i += 1;
    }
    ft_free_set_null(&block->help_cmd[cur]);
    *i += 1;
    return (1);
}

int get_cmd_args(t_block *block)
{
    int i;
    int len;
    
    block->cmd_args = malloc(sizeof(*block->cmd_args) * (block->args_len + 1));
    if (!block->cmd_args)
        return (0);
    i = 0;
    len = 0;
    while (i < block->split_len)
    {
        if (block->help_cmd[i])
            block->cmd_args[len++] = block->help_cmd[i];
        i++;
    }
    block->cmd_args[len] = NULL;
    ft_free_set_null(&block->help_cmd);
    block->cmd = ft_strdup(block->cmd_args[0]);
    return (1);
}

int setup_cmd(t_block *block)
{
    int i;
    
    init_cmd(block);
    
    block->help_cmd = ft_split_count(block->prompt, " ", &block->split_len);
    //printf("number of split: %d\n", block->split_len);
    i = 0;
    while (i < block->split_len)
    {
        if (block->help_cmd[i][0] == '<')
            get_infiles(block, &i);
        else if (block->help_cmd[i][0] == '>')
            get_outfiles(block, &i);
        else
        {
            i++;
            block->args_len++;
        }
    }
    get_cmd_args(block);
    return (1);
}

void    print_cmd(t_block *block)
{
    printf("\ncommand args: \n");
    int i;
    if (block->cmd_args)
    {
        i = 0;
        while (block->cmd_args[i])
            printf("%s\n", block->cmd_args[i++]);
    }
    printf("\ninfiles: \n");
    if (block->infiles)
    {
        t_vdmnode *cur;
        t_redir *redir;
        cur = block->infiles->head;
        while (cur)
        {
            redir = (t_redir *)cur->data;
            printf("type %d, file %s\n", redir->type, redir->file);
            cur = cur->next;
        }
    }
    printf("\noutfiles: \n");
    if (block->outfiles)
    {
        t_vdmnode *cur;
        t_redir *redir;
        cur = block->outfiles->head;
        while (cur)
        {
            redir = (t_redir *)cur->data;
            printf("type %d, file %s\n", redir->type, redir->file);
            cur = cur->next;
        }
    }
    printf("\n\n");
}

/*
int dump_cmd_to_block(t_block *block, t_block *block)
{
    if (!block || !cmd)
        return (0);
    block->cmd_args = block->cmd_args;
    block->infiles = block->infiles;
    block->outfiles = block->outfiles;
    return (1);
}
*/
