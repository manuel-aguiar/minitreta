#include "minishell.h"



int dollar_exit_status(t_block *block, t_ms *ms, int *index, int dol_len)
{
    char    *itoa;
    char    *new;
    
    itoa = ft_itoa(ms->exit_status);
    if (!itoa)
        return (0);
    block->prompt_copy[*index] = '\0';
    new = triple_join(block->prompt_copy, itoa, &block->prompt_copy[*index + dol_len]);
    if (!new)
        return (0);
    *index += ft_strlen(itoa);
    free(itoa);
    free(block->prompt_copy);
    block->prompt_copy = new;
    return (1);
}

int dollar_search_env(t_block *block, t_ms *ms, int *index, int dol_len)
{
    int     i;
    char    *new;
    
    i = 0;
    block->prompt_copy[*index] = '\0';
    if (ms->env)
    {
        while (ms->env[i])
        {
            //printf("current env: [%s], searching for[%s], dol_len %d\n", ms->env[i], &block->prompt_copy[*index + 1], dol_len);
            if (!ft_strncmp(&block->prompt_copy[*index + 1], ms->env[i], dol_len) \
            && ms->env[i][dol_len] == '=')
            {
                new = triple_join(block->prompt_copy, &ms->env[i][dol_len + 1], &block->prompt_copy[*index + 1 + dol_len]);
                if (!new)
                    return (0);
                free(block->prompt_copy);
                block->prompt_copy = new;
                *index += ft_strlen(&ms->env[i][dol_len + 1]);
                //printf("prompt now is [%s]\n", block->prompt_copy);
                return (1);
            }
            i++;
        }
    }
    new = triple_join(block->prompt_copy, "\0", &block->prompt_copy[*index + 1 + dol_len]);
    if (!new)
        return (0);
    free(block->prompt_copy);
    block->prompt_copy = new;
    return (1);
}

int dollar_search_replace(t_block *block, t_ms *ms, int *index)
{
    int len;
    
    if (!block->prompt_copy[*index + 1] || block->prompt_copy[*index + 1] == ' ')
        return (1);
    if (block->prompt_copy[*index + 1] == '?')
        return (dollar_exit_status(block, ms, index, 2));
    len = 0;
    while (block->prompt_copy[*index + 1 + len] && block->prompt_copy[*index + 1 + len] != ' ' \
    && block->prompt_copy[*index + 1 + len] != '\'' && block->prompt_copy[*index + 1 + len] != '"' \
    && block->prompt_copy[*index + 1 + len] != '$')
        len++;
    return (dollar_search_env(block, ms, index, len));
}

int expand_dollars(t_block *block, t_ms *ms)
{
    int i;
    int quote;
    
    quote = 0;
    i = 0;
    while (block->prompt_copy[i])
    {
        if (block->prompt_copy[i] == '\'' || block->prompt_copy[i] == '"')
        {
            if (!quote)
                quote = block->prompt_copy[i];
            else if (quote == block->prompt_copy[i])
                quote = 0;
            i++;
        }
        else if (block->prompt_copy[i] == '$' && (!quote || quote == '"'))
            dollar_search_replace(block, ms, &i);
        else
            i++;
    }
    return (1);
}

int wildcard_search_replace(t_block *block, int *index, char **fail_return)
{
    char    *join;
    char    *new;
    int     count;
    int     start;
    int     end;
    
    start = *index;
    while (start > 0 && block->prompt_copy[start - 1] != ' ' \
    && block->prompt_copy[start - 1] != '<' && block->prompt_copy[start - 1] != '>')
        start--;
    end = *index;
    while (block->prompt_copy[end] && block->prompt_copy[end] != ' ')
        end++;
    join = wildcard(&block->prompt_copy[start], end - start, &count);
    if (count > 1 && fail_return)
    {
        block->prompt_copy[end] = '\0';
        *fail_return = triple_join("\'", &block->prompt_copy[start], "\'");
        free(join);
        return (0);
    }
    block->prompt_copy[start] = '\0';
    new = triple_join(block->prompt_copy, join, &block->prompt_copy[end]);
    if (!new)
        return (0);
    *index += (ft_strlen(join) - *index + start);
    free(block->prompt_copy);
    free(join);
    block->prompt_copy = new;
    
    return (1);
    
}

int expand_wildcards(t_block *block, char **fail_return)
{
    int i;
    int quote;
    
    quote = 0;
    i = 0;
    while (block->prompt_copy[i])
    {
        if (block->prompt_copy[i] == '\'' || block->prompt_copy[i] == '"')
        {
            if (!quote)
                quote = block->prompt_copy[i];
            else if (quote == block->prompt_copy[i])
                quote = 0;
            i++;
        }
        else if (block->prompt_copy[i] == '*' && !quote)
        {
            //printf("PROMPT [%s]\n", &block->prompt_copy[i]);
            if (!wildcard_search_replace(block, &i, fail_return))
                return (0);
        }
        else
            i++;
    }
    return (1);
}



//expand_dollars(&pmt, ms);
//expand_wildcards(&pmt);

int free_cmd(t_block *block)
{
    if (block->cmd)
        ft_free_set_null(&block->cmd);
    if (block->cmd_args)
        ft_free_charmat_null(&block->cmd_args, free);
    if (block->io_files)
        vdmlist_destroy(&block->io_files, destroy_redir);
    if (block->cmd_args_copy)
        ft_free_set_null(&block->cmd_args_copy);
    if (block->help_cmd)
        ft_free_sizemat_null(&block->help_cmd, block->split_len, free);
    return (1);
}

int init_cmd(t_block *block)
{
    block->cmd = NULL;
    block->cmd_args = NULL;
    block->io_files = NULL;
    block->prompt_copy = NULL;
    block->cmd_args_copy = NULL;
    block->args_len = 0;
    block->split_len = 0;
    block->help_cmd = NULL;
    return (1);
}

int get_outfiles(t_block *block, int *i)
{
    int     type;
    int     cur;
    int     c;
    
    cur = *i;
    c = 1;
    if (!block->io_files)
        block->io_files = vdmlist_new();
    if (block->cmd_args_copy[cur][c] == '>')
    {
        type = RE_APPEND;
        c++;
    }
    else
        type = RE_TRUNC;
    if (block->cmd_args_copy[cur][c])
        vdmlist_in_tail(block->io_files, init_redir(ft_strdup(&block->cmd_args_copy[cur][c]), type));
    else
    {
        vdmlist_in_tail(block->io_files, init_redir(block->cmd_args_copy[cur + 1], type));
        block->cmd_args_copy[cur + 1] = NULL;
        *i += 1;
    }
    ft_free_set_null(&block->cmd_args_copy[cur]);
    *i += 1;
    return (1);
}

/*
    get_infiles
    function checks the infile name and type and inserts it into the redirection list
    So far, no expansion of env or wildcards is done at this stage.
    Will probably change it such that if ambiguous redirection, not worth to
    keep looking at more stuff to check
    potential ambiguous redirections are checked upon opening the files individuallly
    so we can process redirections before processing the rest of the arguments as we go
    as needed.


*/

int get_infiles(t_block *block, int *i)
{
    int     type;
    int     cur;
    int     c;
    
    cur = *i;
    c = 1;
    if (!block->io_files)
        block->io_files = vdmlist_new();
    if (block->cmd_args_copy[cur][c] == '<')
    {
        type = RE_HEREDOC;
        c++;
    }
    else
        type = RE_INFILE;
    if (block->cmd_args_copy[cur][c])
        vdmlist_in_tail(block->io_files, init_redir(ft_strdup(&block->cmd_args_copy[cur][c]), type));
    else
    {
        vdmlist_in_tail(block->io_files, init_redir(block->cmd_args_copy[cur + 1], type));
        block->cmd_args_copy[cur + 1] = NULL;
        *i += 1;
    }
    ft_free_set_null(&block->cmd_args_copy[cur]);
    *i += 1;
    return (1);
}

/*
    cmd_args_has_space_split
    This function lacks creativity in it's naming.
    sees if an argument has space in it (after confirming it is not between quotes)
    and splits and updates the full list....
    
    it sees what the new total is, gets the split "split", allocates "new" for the new total.
    copies all block->cmd_args in order, then inserts the split, copies the remaining cmd_args
    and thhen frees the holding array of the old block->cmd_args and split (all the pointers
    were passed to "new", we don't want to free those).
    
    (it also frees the cmd_arg[index] in the middle that we split, since we won't use that anymore)
    
    And we go back to the original loop.
    #ugliest_function_ever
*/

int cmd_args_has_space_split(t_block *block, int *index)
{
    int     i;
    int     count;
    char    **split;
    char    **new;
    
    i = 0;
    while (block->cmd_args[*index][i] && !ft_isspace(block->cmd_args[*index][i]))
        i++;
    if (!block->cmd_args[*index][i])
        return (1);
    
    split = ft_split_count(block->cmd_args[*index], " ", &count);
    //printf("args before: %d, this arg [%s], count %d\n", block->args_len, block->cmd_args[*index], count);
    if (!split)
        return (0);
    ft_free_set_null(&block->cmd_args[*index]);
    block->args_len += count - 1;
    //printf("new total count %d\n", block->args_len);
    new = malloc(sizeof(*new) * (block->args_len + 1));
    if (!new)
    {
        ft_free_charmat_null(&split, free);
        return (0);
    }
    i = 0;
    while (i < block->args_len)
    {
        if (i < *index)
        {
            new[i] = block->cmd_args[i];
            i++;
        }
        else if (i == *index)
        {
            while (i - *index < count)
            {
                new[i] = split[i - *index];
                //printf("new[%d] = [%s]\n", i, new[i]);
                i++;
            }
        }
        else if (i < block->args_len)
        {
            new[i] = block->cmd_args[i - count + 1];
            //printf("new[%d] = [%s]\n", i, new[i]);
            i++;
        }
    }
    new[i] = NULL;
    ft_free_set_null(&block->cmd_args);
    ft_free_set_null(&split);
    block->cmd_args = new;
    *index += (count - 1);
    return (1);
}

/*
    cmd_args_rm_quotes_and_split
    This function removes the outter quotes of each argument.
    If there are no outter quotes but the argument can be
    split in spaces due to dollar/wildcard expansion, a split will be made
    into further individual arguments.
*/

int cmd_args_rm_quotes_and_split(t_block *block)
{
    int i;
    
    i = 0;
    while (block->cmd_args[i])
    {
        if (block->cmd_args[i][0] == '\'' \
        || block->cmd_args[i][0] == '"')
        {
            block->cmd_args[i][ft_strlen(block->cmd_args[i]) - 1] = '\0';
            block->prompt_copy = ft_strdup(&block->cmd_args[i][1]);
            if (!block->prompt_copy)
                return (0);
            free(block->cmd_args[i]);
            block->cmd_args[i] = block->prompt_copy;
        }
        else
        {
            if (!cmd_args_has_space_split(block, &i))
                return (0);
        }
        i++;
    }
    return (1);
}

/*
    cmd_args_expand_dollar_wildcard
    As per the name, goes through all the cmd_args and expands wildcards 
    and envieronment variables within each.
    Expand dollars in every case except \'.
    Expand wildcards whenever there are no quotes surrounding the argument.
    We use block->prompt_copy to hold our argument to the other function calls,
    just to spare one variable....
*/

int cmd_args_expand_dollar_wildcard(t_block *block)
{
    int i;
    
    i = 0;
    while (block->cmd_args[i])
    {
        if (block->cmd_args[i][0] != '\'')
        {
            block->prompt_copy = block->cmd_args[i];
            expand_dollars(block, block->ms);
            block->cmd_args[i] = block->prompt_copy;
            block->prompt_copy = NULL;
        }
        if (block->cmd_args[i][0] != '\'' \
        && block->cmd_args[i][0] != '"')
        {
            block->prompt_copy = block->cmd_args[i];
            expand_wildcards(block, NULL);
            block->cmd_args[i] = block->prompt_copy;
            block->prompt_copy = NULL;
        }
        i++;
    }
    return (1);
} 



/*
    get_cmd_args
    
    after having succeessfully removed redirections to the linkedlist,
    we agreggate the remaining split since they are all the command args.
    after that, we will need to expand wildcards, environment and
    remove quotes
    
    expansion of enviroment variables and wildcards must occur seperatelly
    in cmd_args and io_files because on the latter, multiple io_files
    per redirection will result in ambiguous redirection and execution must
    therefore stop there. So, we can manage io_files before continuing expanding
    the command, since once we find a problem in redirections, the rest is not
    really needed because execution will stop anyways.
    
    at the end, we can do ft_free_set_null to block->cmd_args_copy (despite being char **)
    because we have successefully moved all addresses we wanted to block->cmd_args
    therefore, no malloc'ed pointers are being held exclusively by block->cmd_args_copy and we can
    free the main char** directly.

*/



int get_cmd_args(t_block *block)
{
    int i;
    int len;
    
    block->cmd_args = malloc(sizeof(*block->cmd_args) * (block->args_len + 1));
    if (!block->cmd_args)
        return (0);
    i = 0;
    len = 0;
    while (i < block->split_len)
    {
        if (block->cmd_args_copy[i])
            block->cmd_args[len++] = block->cmd_args_copy[i];
        i++;
    }
    block->cmd_args[len] = NULL;
    ft_free_set_null(&block->cmd_args_copy);
    if (!cmd_args_expand_dollar_wildcard(block))
        return (0);
    if (!cmd_args_rm_quotes_and_split(block))
        return (0);
    block->cmd = ft_strdup(block->cmd_args[0]);
    if (!block->cmd)
        return (0);
    return (1);
}

/* 
    split_cmd_by_quotes_spaces
    make a copy of the original, set characters between quotes to an 
    arbitrary non-space value. 
    split by spaces (spaces between quotes will be set to something else)
    loop through the whole thing to replenish the empty quotes with the original values

*/
int split_cmd_by_quotes_spaces(t_block *block)
{
    block->prompt_copy = ft_strdup(block->prompt);
    if (!block->prompt_copy)
        return (0);
    set_in_between_to(block->prompt_copy, '"', '"', -1);
    set_in_between_to(block->prompt_copy, '\'', '\'', -1);
    //printf("copy is [%s]\n", block->prompt_copy);
    block->cmd_args_copy = ft_split_count_replenish(block->prompt_copy, block->prompt, " ", &block->split_len);
    //printf("args 0 [%s]\n", block->cmd_args_copy[0]);
    //printf("args 1 [%s]\n", block->cmd_args_copy[1]);
    if (!block->cmd_args_copy)
        return (0);
    ft_free_set_null(&block->prompt_copy);
    return (1);
}

/*
    setup_cmd
    preparing the command for execution
    here we take the prompt, which we have identified already as a final command and:
        - separate redirections
        - expand environment variables
        - expand wildcards
        - remove quotes

*/

int setup_cmd(t_block *block)
{
    int i;
    
    init_cmd(block);
    if (!split_cmd_by_quotes_spaces(block))
        return (0);
    i = 0;
    while (i < block->split_len)
    {
        if (block->cmd_args_copy[i][0] == '<')
            get_infiles(block, &i);
        else if (block->cmd_args_copy[i][0] == '>')
            get_outfiles(block, &i);
        else
        {
            i++;
            block->args_len++;
        }
    }
    if (block->args_len)
        get_cmd_args(block);
    return (1);
}

void    print_cmd(t_block *block)
{
    printf("\ncommand args: \n");
    int i;
    if (block->cmd_args)
    {
        i = 0;
        while (block->cmd_args[i])
            printf("%s\n", block->cmd_args[i++]);
    }
    printf("\ninfiles: \n");
    if (block->io_files)
    {
        t_vdmnode *cur;
        t_redir *redir;
        cur = block->io_files->head;
        while (cur)
        {
            redir = (t_redir *)cur->data;
            printf("type %d, file %s\n", redir->type, redir->file);
            cur = cur->next;
        }
    }
    printf("\noutfiles: \n");
    if (block->io_files)
    {
        t_vdmnode *cur;
        t_redir *redir;
        cur = block->io_files->head;
        while (cur)
        {
            redir = (t_redir *)cur->data;
            printf("type %d, file %s\n", redir->type, redir->file);
            cur = cur->next;
        }
    }
    printf("\n\n");
}

/*
int dump_cmd_to_block(t_block *block, t_block *block)
{
    if (!block || !cmd)
        return (0);
    block->cmd_args = block->cmd_args;
    block->io_files = block->io_files;
    block->io_files = block->io_files;
    return (1);
}
*/


/* TODO LIST

Refazer o split dos comandos, tem de ter em conta as aspas e está apenas a separar por
espaços
Depois do split de comandos, é preciso retirar as aspas exteriores de cada um dos comandos

Espansão de environment variables que inclui split normal por espaços

Expansão de wildcards


Expansao de env e wildcards tem de ser feita em separado na gestao de ficheiros
e em cmd args

em cmd args, vai tudo junto
em manage_io_files pode resultar em ambiguous redirection


*/
