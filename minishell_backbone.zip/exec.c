/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.exec.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/01 12:32:48 by marvin            #+#    #+#             */
/*   Updated: 2023/06/01 12:32:48 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	perror_msg(char *text)
{
	perror(text);
	return (0);
}

int	error_msg(char *text)
{
	ft_putstr_fd(text, STDERR_FILENO);
	return (0);
}

void	perror_child_exit(t_block *block, char *text, int close_io)
{
	if (text)
		perror(text);
	if (close_io == 1)
	{
		close(block->final_in);
		close(block->final_out);
	}
	//if (block->father->pipefd[0] != -1)
	//	close(block->father->pipefd[0]);
	block->ms->exit_status = 127;    //  ??????????????????????????????
	//destroy_block(block);
	exit(EXIT_FAILURE);
}

int	join_path_bin(char **full_path, char *path, char *bin)
{
	int		path_len;
	int		bin_len;
	char	*new;

	path_len = ft_strlen(path);
	if (path[path_len - 1] == '/')
		path_len--;
	bin_len = ft_strlen(bin);
	new = malloc(sizeof(*new) * (path_len + bin_len + 1 + 1));
	if (!new)
	{
		*full_path = new;
		return (perror_msg(ERR_MALLOC));
	}
	ft_memcpy(new, path, path_len);
	new[path_len] = '/';
	ft_memcpy(&new[path_len + 1], bin, bin_len);
	new[path_len + bin_len + 1] = '\0';
	*full_path = new;
	return (1);
}

int	exec_cmd_with_path(t_block *block)
{
	if (access(block->cmd, F_OK))
		return (perror_msg(block->cmd));
	else if (execve(block->cmd, block->cmd_args, block->ms->env) == -1)
		return (perror_msg(block->cmd));
	return (1);
}

int	exec_cmd_search_path(t_block *block)
{
	int		i;
	char	*full_path;
    
    if (!block->ms->path)
    {
        dprintf(block->ms->errfd, "minishell: %s: command not found\n", block->cmd);
        return (0);
    }
	i = 0;
	while (block->ms->path[i])
	{
		if (!join_path_bin(&full_path, block->ms->path[i++], block->cmd))
			return (0);
		if (access(full_path, F_OK) == 0)
		{
			if (execve(full_path, block->cmd_args, block->ms->env) == -1)
			{
				perror(block->cmd);
				ft_free_set_null(&full_path);
				return (0);
			}
		}
		else
			ft_free_set_null(&full_path);
		
	}
	return (0);    //error messageeeeeee
}

int	exec_command(t_block *block)
{
	if (ft_strrchr(block->cmd, '/'))
	{
	    //printf("absolute path\n");
		exec_cmd_with_path(block);
	}
	else
		exec_cmd_search_path(block);
	//destroy_block(block);
	return (0);
}

int	child_process(t_block *block)
{
    if (block->final_in != block->ms->infd)
    {
        if (dup2(block->final_in, block->ms->infd) == -1)
            perror_child_exit(block, ERR_DUP2, TRUE);
        close_in_fds(block);
    }
    if (block->final_out != block->ms->outfd)
    {
        if (dup2(block->final_out, block->ms->outfd) == -1)
            perror_child_exit(block, ERR_DUP2, TRUE);
        close_out_fds(block);
    }    
	if (!exec_command(block))
		perror_child_exit(block, NULL, FALSE);
	return (0);
}

int	parent_process(t_block *block)
{
	if (block->tmp_name)
	{
		unlink(block->tmp_name);
		ft_free_set_null(&block->tmp_name);
	}
	close_in_fds(block);
	close_out_fds(block);
	return (1);
}

int	process_execution(t_block *block)
{
	int	    i;
	pid_t   pid;

	i = 0;
	pid = fork();
	if (block->father)
	    block->father->child_pids[block->my_id] = pid;
	else
	    block->ms->my_kid = pid;
	if (pid == -1)
		return (perror_msg(ERR_FORK));
	if (!pid)
		child_process(block);
	
	parent_process(block);
    
    // parent decides about exit status blablabla
    
	return (1);
}
