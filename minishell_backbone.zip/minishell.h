/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 10:08:39 by marvin            #+#    #+#             */
/*   Updated: 2023/08/25 10:49:39 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H

# define MINISHELL_H

# include <fcntl.h>
# include <stdlib.h>
# include <stdio.h>
# include <unistd.h>
# include <stdio.h>
# include <limits.h>
# include <sys/wait.h>
# include <errno.h>

# include "libft.h"

# define TRUE 1
# define FALSE 0

# define MYNAME "minishell"

# define ERR_PIPE "pipe"
# define ERR_FORK "fork"
# define ERR_DUP "dup"
# define ERR_OPEN "open"
# define ERR_DUP2 "dup2"
# define ERR_MALLOC "malloc"
# define ERR_CMD "command not found"

typedef struct s_ms		t_ms;
typedef struct s_block	t_block;
typedef struct s_redir	t_redir;

struct s_ms
{
	char		**env;
	char		**path;
	char		*prompt;
	char		name[10];
	int			infd;
	int			outfd;
	int         errfd;
	int			exit_status;
	t_block		*first;
	pid_t       my_kid;
};

struct s_block
{
    char		*prompt;	 //herdado do bloco pai;
    int     	infd;	    //herdado do bloco pai;
    int     	outfd;	   //herdado do bloco pai;
	t_ms		*ms;		//to access and change env and path
	t_block		*father;	// to comunicate exit status with the parent

    char    **children;
    pid_t     *child_pids;
    int     *op_id;
    int     op_count;
    char    *help_pmt;
    int     is_cmd;

    int  	   pipefd[2];      //posso precisar para unir os blocos filhos
    int  	   status;	  // recebido dos filhos para informar o avô;    
    
    char    	*cmd;	    //decomposição do prompt
    char    	**cmd_args;     //decomposição do prompt
    t_vdmlist  *infiles;	//decomposição do prompt, farão override ao infd do block, deixa de heredar do bloco anterior  void *list, com struct t_redir;
    t_vdmlist  *outfiles;      //decomposição do prompt, farão override ao outfd do block, deixa de heredar do bloco anterior void *list, com struct t_redir;
    char        *tmp_name;     //here_doc, just in case, analisado um a um;
    int         final_in;
    int         final_out;
    char        **help_cmd;
    int         args_len;
    int         split_len;
    
    int         my_id;
};

struct s_redir
{
    char    *file;
    int     type;
};


enum e_op
{
	OP_AND = 1,
	OP_OR,
	OP_PIPE,
};

enum e_redir
{
    RE_HEREDOC = 1,
    RE_INFILE,
    RE_TRUNC,
    RE_APPEND,
};


int		ft_matrixlen(void *mat);
int		ft_charmatdup(char ***dest, char **src);
void	*quicksort_pointers(void *arr, int size, int (*cmp)(void *, void *));
int		env_strcmp(void *s1, void *s2);


/*bi_export.c*/
int		export_bi(t_ms *ms, int ac, char **av);

/*bi_unset.c*/
int		unset_bi(t_ms *ms, int ac, char **av);

int	ft_matrixlen(void *mat);
int	ft_charmatdup(char ***dest, char **src);
int init_ms(t_ms *ms, char **env);



/*free_all*/
int	free_all(t_ms *ms);


/* init_destroy */
int init_ms(t_ms *ms, char **env);
int	destroy_ms(t_ms *ms);
t_block	*init_block(t_ms *ms, t_block *father, char *pmt, int my_id);
void	destroy_block(void *og_block);
t_redir *init_redir(char *file, int type);
void	destroy_redir(void *og_redir);




# define EXIT_SYNTAX 2

typedef struct s_prompt
{
    char    *prompt;
    char    *copy;
    int     parenthesis;
    int     first_error_index;
    int     exit_status;
    char    *err_token;
}   t_prompt;



int get_prompt(t_ms *ms);

int syntax_error_msg(t_prompt *pmt);
int syntax_error_manager(t_prompt *pmt, int err_code, char *err, int position);
int validate_parenthesis_close(t_prompt *pmt);
int validate_quote_close(t_prompt *pmt);
int syntax_operators_end(t_prompt *pmt);
int syntax_redir_end(t_prompt *pmt);
int syntax_redirections(t_prompt *pmt);
int syntax_operators(t_prompt *pmt);
int open_prths_helper(char *copy, int index);
int close_prths_helper(char *copy, int index);
int syntax_parenthesis(t_prompt *pmt);
int syntax_begin(t_prompt *pmt);
int validate_syntax(t_prompt *pmt);
int copy_empty_quotes(t_prompt *pmt);
int setup_prompt_struct(t_prompt *pmt);
int get_prompt(t_ms *ms);
void rm_unnecessary_parenthesis(t_prompt *pmt);
void rm_corner_parenthesis(char *copy, char *original);



//functions to split prompt into children

int split_prompt(t_block *block);
int split_children(t_block *block);
int split_get_operator(t_block *block, int index, int count);
int free_split_prompt(t_block *block);
int count_operators(char *copy);
int copy_empty_quotes_and_parenthesis(t_block *block);
void    empty_parenthesis(char *pmt);
void    print_split(t_block *block);



//functions to prepare commands

int free_cmd(t_block *block);
int init_cmd(t_block *block);
int get_outfiles(t_block *block, int *i);
int get_infiles(t_block *block, int *i);
int get_cmd_args(t_block *block);
int setup_cmd(t_block *block);
void    print_cmd(t_block *block);
//int dump_cmd_to_block(t_block *block, t_block *block);




int manage_infiles(t_block *block);
int manage_outfiles(t_block *block);


/* exec.c */
/*
int	join_path_bin(char **full_path, char *path, char *bin);
int	exec_cmd_with_path(t_pipex *pipex, char ***args);
int	exec_cmd_search_path(t_pipex *pipex, char ***args);
int	exec_command(t_pipex *pipex, char *cmd);
*/


/* error_message.c */
int	perror_msg(char *text);
int	error_msg(char *text);
void	perror_child_exit(t_block *block, char *text, int close_io);

int	exec_command(t_block *block);
int	process_execution(t_block *block);



#endif
