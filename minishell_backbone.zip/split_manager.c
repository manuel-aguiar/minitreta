
#include "minishell.h"

void    set_in_between_to(char *pmt, char start, char end, char newchar)
{
    int i;
    int open;

    open = 0;
    i = 0;
    while (pmt[i])
    {
        while (pmt[i] && pmt[i] != start)
            i++;
        if (pmt[i])
        {
            open = 1;
            i++;
            while (pmt[i] && open)
            {
                if (pmt[i] == start)
                    open++;
                if (pmt[i] == end)
                {
                    open--;
                    if (end == start)
                        open--;
                }
                if (open)
                    pmt[i++] = newchar;
            }
        }
    }
}

int copy_empty_quotes_and_parenthesis(t_block *block)
{
    int i;
    int quote;
    int open;
    char *copy;
    
    copy = ft_strdup(block->prompt);
    if (!copy)
        return (0);
    i = 0;
    quote = 0;
    while (block->prompt[i])
    {
        while (block->prompt[i] && block->prompt[i] != '\'' && block->prompt[i] != '"')
            i++;
        if (block->prompt[i])
        {
            quote = block->prompt[i++];
            while (block->prompt[i] && block->prompt[i] != quote)
                copy[i++] = ' ';
            if (block->prompt[i] == quote)
            {
                quote = 0;
                i++;
            }
        }
    }
    copy[i] = '\0';
    rm_corner_parenthesis(copy, block->prompt);
    set_in_between_to(copy, '(', ')', ' ');
    block->help_pmt = copy;
    return (1);
}






int count_operators(char *copy)
{
    int i;
    int count;
    
    count = 0;
    i = 0;
    while (copy[i])
    {
        if (copy[i] == '&' || copy[i] == '|')
        {
            count++;
            i++;
            if (copy[i] && copy[i] == copy[i - 1])
                i++;
        }
        i++;
    }
    return (count);
}

int free_split_prompt(t_block *block)
{
    if (block->help_pmt)
        ft_free_set_null(&block->help_pmt);
    if (block->children)
        ft_free_charmat_null(&block->children, free);
    if (block->op_id)
        ft_free_set_null(&block->op_id);
    if (block->child_pids)
        ft_free_set_null(&block->op_id);
    return (0);
}

int split_get_operator(t_block *block, int index, int count)
{
    if (block->help_pmt[index] == block->help_pmt[index + 1])
    {
        if (block->help_pmt[index] == '|')
            block->op_id[count] = OP_OR;
        if (block->help_pmt[index] == '&')
            block->op_id[count] = OP_AND;
        index++;
    }
    else
        block->op_id[count] = OP_PIPE;
    index++;
    return (index);
}

int split_children(t_block *block)
{
    int len;
    int all;
    int i;
    
    all = 0;
    i = 0;
    while (all < block->op_count)
    {
        len = 0;
        while (block->help_pmt[i + len] != '&' && block->help_pmt[i + len] != '|')
            len++;
        block->children[all] = malloc(sizeof(*(block->children[all])) * (len + 1));
        if (!block->children[all])
            return (free_split_prompt(block));
        ft_memcpy(block->children[all], &block->prompt[i], len);
        block->children[all][len] = '\0';
        //printf("%s\n", block->children[all]);
        i = split_get_operator(block, i + len, all);
        all++;
    }
    block->children[all++] = ft_strdup(&block->prompt[i]);
    if (block->children[all])
        return (free_split_prompt(block));
    //printf("%s\n", block->children[all - 1]);
    block->children[all] = NULL;
    return (1);
}

void refill_child(t_block *block)
{
    int i;
    int j;
    int k;
    char *copy;
    
    i = 0;
    while (i < block->split_len && !block->help_cmd[i])
        i++;
    block->children[0] = block->help_cmd[i];
    block->help_cmd[i] = NULL;
    j = 0;
    while (block->children[0][j] && block->children[0][j] != '(')
        j++;
    k = 0;
    while (block->prompt[k] && block->prompt[k] != '(')  
        k++;
    while (block->prompt[k] && block->prompt[k] != ')')
        block->children[0][j++] = block->prompt[k++];
    copy = ft_strdup(block->children[0]);                                   // worst code ever
    rm_corner_parenthesis(copy, block->children[0]);                          // worst code ever
    free(copy);
}

int split_redirections(t_block *block)
{
    int i;
    
    init_cmd(block);
    set_in_between_to(block->help_pmt, '(', ')', 'a');
    block->help_cmd = ft_split_count(block->help_pmt, " ", &block->split_len);
    if (!block->help_cmd)
        return (0);
    i = 0;
    while (i < block->split_len)
    {
        if (block->help_cmd[i][0] == '<')
            get_infiles(block, &i);
        else if (block->help_cmd[i][0] == '>')
            get_outfiles(block, &i);
        else
        {
            i++;
            block->args_len++;
        }
        
    }
    refill_child(block);
    return (1);
}


int split_prompt(t_block *block)
{
    int i;
    
    if (!copy_empty_quotes_and_parenthesis(block))
        return (0);
    block->op_count = count_operators(block->help_pmt);
    block->op_id = malloc(sizeof(*(block->op_id)) * block->op_count);
    block->children = ft_calloc((block->op_count + 2), sizeof(*(block->children)));
    if (!block->op_id || !block->children)
        return (free_split_prompt(block));
    if (!split_children(block))
        return (free_split_prompt(block));
    if (block->op_count == 0)
    {
        i = 0;
        while (block->help_pmt[i] && block->help_pmt[i] != '(')
            i++;
        if (!block->help_pmt[i])
            block->is_cmd = 1;
        else
            split_redirections(block);
    }
    block->child_pids = ft_calloc(block->op_count + 1, sizeof(*(block->child_pids)));
    ft_free_set_null(&block->help_pmt);
    return (1);
}

void    print_split(t_block *block)
{
    printf("split operators: %d, they are:\n", block->op_count);
    int i = 0;
    if (block->op_id)
    {
        while (i < block->op_count)
            printf("%d ", block->op_id[i++]);
    }
    printf("\n children are: \n");
    i = 0;
    if (block->children)
    {
        while (i < block->op_count + 1)
            printf("%s\n", block->children[i++]);
    }
    printf("total %d args\n", i);
}



