
#include "minishell.h"

void    empty_parenthesis(char *pmt)
{
    int i;
    int open;

    open = 0;
    i = 0;
    while (pmt[i])
    {
        while (pmt[i] && pmt[i] != '(')
            i++;
        if (pmt[i])
        {
            open = 1;
            i++;
            while (pmt[i] && open)
            {
                if (pmt[i] == '(')
                    open++;
                if (pmt[i] == ')')
                    open--;
                if (open)
                    pmt[i++] = ' ';
            }
        }
    }
}

int copy_empty_quotes_and_parenthesis(t_split *split)
{
    int i;
    int quote;
    int open;
    char *copy;
    
    copy = ft_strdup(split->prompt);
    if (!copy)
        return (0);
    i = 0;
    quote = 0;
    while (split->prompt[i])
    {
        while (split->prompt[i] && split->prompt[i] != '\'' && split->prompt[i] != '"')
            i++;
        if (split->prompt[i])
        {
            quote = split->prompt[i++];
            while (split->prompt[i] && split->prompt[i] != quote)
                copy[i++] = ' ';
            if (split->prompt[i] == quote)
            {
                quote = 0;
                i++;
            }
        }
    }
    copy[i] = '\0';
    empty_parenthesis(copy);
    split->copy = copy;
    return (1);
}






int count_operators(char *copy)
{
    int i;
    int count;
    
    count = 0;
    i = 0;
    while (copy[i])
    {
        if (copy[i] == '&' || copy[i] == '|')
        {
            count++;
            i++;
            if (copy[i] && copy[i] == copy[i - 1])
                i++;
        }
        i++;
    }
    return (count);
}

int free_split_prompt(t_split *split)
{
    t_split *cur;
    if (split->copy)
        ft_free_set_null(&split->copy);
    if (split->children)
        ft_free_charmat_null(&split->children, free);
    if (split->operators)
        ft_free_set_null(&split->operators);
    return (0);
}

int split_get_operator(t_split *split, int index, int count)
{
    if (split->copy[index] == split->copy[index + 1])
    {
        if (split->copy[index] == '|')
            split->operators[count] = OP_OR;
        if (split->copy[index] == '&')
            split->operators[count] = OP_AND;
        index++;
    }
    else
        split->operators[count] = OP_PIPE;
    index++;
    return (index);
}

int split_children(t_split *split)
{
    int len;
    int all;
    int i;
    
    all = 0;
    i = 0;
    while (all < split->op_count)
    {
        len = 0;
        while (split->copy[i + len] != '&' && split->copy[i + len] != '|')
            len++;
        split->children[all] = malloc(sizeof(*(split->children[all])) * (len + 1));
        if (!split->children[all])
            return (free_split_prompt(split));
        ft_memcpy(split->children[all], &split->prompt[i], len);
        split->children[all][len] = '\0';
        //printf("%s\n", split->children[all]);
        i = split_get_operator(split, i + len, all);
        all++;
    }
    split->children[all++] = ft_strdup(&split->prompt[i]);
    if (split->children[all])
        return (free_split_prompt(split));
    //printf("%s\n", split->children[all - 1]);
    split->children[all] = NULL;
    return (1);
}

int split_prompt(t_split *split)
{
    if (!copy_empty_quotes_and_parenthesis(split))
        return (0);
    split->op_count = count_operators(split->copy);
    split->operators = malloc(sizeof(*(split->operators)) * split->op_count);
    split->children = ft_calloc((split->op_count + 2), sizeof(*(split->children)));
    if (!split->operators || !split->children)
        return (free_split_prompt(split));
    if (!split_children(split))
        return (free_split_prompt(split));
    return (1);
}

void    print_split(t_split *split)
{
    printf("split operators: %d, they are:\n", split->op_count);
    int i = 0;
    if (split->operators)
    {
        while (i < split->op_count)
            printf("%d ", split->operators[i++]);
    }
    printf("\n children are: \n");
    i = 0;
    if (split->children)
    {
        while (i < split->op_count + 1)
            printf("%s\n", split->children[i++]);
    }
    printf("\n");
}



