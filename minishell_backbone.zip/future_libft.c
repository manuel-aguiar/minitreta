#include "libft.h"

int	ft_matrixlen(void *mat)
{
	t_uchar **move;
	int			i;

	if (!mat)
		return (-1);
	move = (t_uchar **)mat;
	i = 0;
	while (move[i])
		i++;
	return (i);
}

int	ft_charmatdup(char ***dest, char **src)
{
	char	**res;
	int		len;
	int		i;

	len = ft_matrixlen(src);
	res = malloc((len + 1) * sizeof(*res));
	if (!res)
		return (0);
	i = 0;
	while (i < len)
	{
		res[i] = ft_strdup(src[i]);
		if (!res[i])
		{
			ft_free_charmat_null(&res, &free);
			*dest = res;
			return (0);
		}
		i++;
	}
	res[i] = NULL;
	*dest = res;
	return (1);
}