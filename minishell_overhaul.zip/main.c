/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/25 09:52:17 by marvin            #+#    #+#             */
/*   Updated: 2023/08/25 09:52:17 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/*

    waiting_for_my_children
    blocks waits for all the live children and, after arriving, sets their 
    child_pid to zero to signal that either it is a manager and has no pid
    or that the child has already arrived because another conditional needed it 
    to arrive before.
    
    Called by a manager block to wait for all its children and to decide 
    on conditionals whether to proceed or not.
    
    t_ms will call its only pid if needed, corresponding to a single command
    with no manager behind other than t_ms itself.
    
*/

int waiting_for_my_children(t_block *block, int index)
{
    int i;
    
    check_for_signals(block->ms);
    i = 0;
    while (i < index)
    {
        if (block->child_pids[i] != 0)
        {
            waitpid(block->child_pids[i], &block->ms->exit_status, 0);
            if (WIFEXITED(block->ms->exit_status))
                block->ms->exit_status = WEXITSTATUS(block->ms->exit_status);
            block->child_pids[i] = 0;
        }
        i++;
    }
    return (1);
}

/*

    pipes_and_conditionals
    Sets up the commands based on the big 3 operators: && || and |.
        -   Saves the read end of the previous pipe, if a pipe was open
            the next operator may be a pipe as well: pipe will overwrite
            the previous file descriptors
        -   Opens a new pipe if the current command will write too a pipe;
        -   In case of && or ||, waits for the previous commands to arrive
            in order to determine their exit status and decide wether
            the following command will execute or not;

*/

int pipes_and_conditionals(t_block *block, int index)
{
    if (index > 0 && block->op_id[index - 1] == OP_PIPE)
        block->pp_readfd = block->pipefd[0];
    if (index < block->op_count && block->op_id[index] == OP_PIPE)
    {
        if (pipe(block->pipefd) == -1)
            return (0);                                                         //must give an error message for failure to open a pipe
    }
    if (index > 0 && index <= block->op_count \
    && (block->op_id[index - 1] == OP_AND || block->op_id[index - 1] == OP_OR))
    {
        waiting_for_my_children(block, index);
        if ((block->op_id[index - 1] == OP_AND && block->ms->exit_status != 0) \
        || (block->op_id[index - 1] == OP_OR && block->ms->exit_status == 0))
            return (0);
    }
    return (1);
}



/*
    execute
    This function prepares the command for execution.
    If redirections have a problem (ambiguous/non existent), close the remaining file descriptors
    and exit.
    
    If there is no command (the prompt is made of only redirections, totally legal)
    just close the file descriptors and exit.
    
    Otherwise, call process_execution: responsible for fork and execve.

*/

int execute(t_block *block)
{
    //setup_cmd(block);
    if (block->cmd)
        process_execution(block);
    else
    {
        close_in_fds(block);
        close_out_fds(block);
    }
    return (1);
}

/*

    execution_tree
    function responsible for the whole thing, pretty much.
    all the t_blocks are set in the stack frame created for the caller: when
    calling destroy_block it just frees the malloc'ed pointers inside the structure
    but not the structure itself (it is destroyed when the function exists)
    When dealing with a father with multiple kids, the previous kid cleans the structure
    when exiting their function call such that the father can use it again from scratch
    for the next kid:
        All Quiet on the Western Front
    so for instance with: ls | cat | cat | cat | cat
    only 2 blocks exist at any given time as one child is done, its function call to execution_tree
    will destroy his own block upon exiting (the child must call destroy_block anyways)
    Upon execution, all the fds are analysed before the command itself, so if
    any fd fails to open, the command won't analyse it s own arguments.
    


*/


int execution_tree(t_block *block)
{
    int         i;
    
    if (!manage_io_files(block))
        return (0);
    if (block->is_cmd)
        execute(block);
    else
    {
        i = 0;
        while (block->child_list[i])
        {
            if (block->op_id && pipes_and_conditionals(block, i))
                execution_tree(block->child_list[i]);
            i++;
        }
        waiting_for_my_children(block, block->op_count + 1);
        close_in_fds(block);
        close_out_fds(block);
    }
    destroy_block(block);
    return (1);
}


void    print_execution_tree(t_block *block)
{
    int i;
    
    i = 0;
    if (!block)
        return ;
    printf("lvl %d, id %d, prompt [%s]\n", block->my_level, block->my_id, block->prompt);
    if (!block->is_cmd)
    {
        i = 0;
        while (block->child_list[i])
        {
            print_execution_tree(block->child_list[i]);
            i++;
        }
    }
}

int setup_execution_tree(t_ms *ms, t_block *father, char *pmt, int my_id)
{
    int     i;
    t_block *block;
    
    block = init_block(ms, father, pmt, my_id);
    if (!block)
        return (0);
    if (!split_prompt(block))
        return (0);
    if (block->is_cmd && !setup_cmd(block))
        return (0);
    if (!block->is_cmd)
    {
        i = 0;
        while (block->child_prompts[i])
        {
            setup_execution_tree(ms, block, block->child_prompts[i], i);
            i++;
        }
        block->child_list[i] = NULL;
        ft_free_charmat_null(&block->child_prompts, free);
    }
    return (1);
}

int ms_prompt_loop(t_ms *ms)
{
    while (1)
	{
    	if (get_prompt(ms))
    	{
    	    //setup the whole fuckin tree;
    	    setup_execution_tree(ms, NULL, ms->prompt, 0);
    	    execution_tree(ms->first);
    	    destroy_block(ms->first);
        	//execution_tree(ms, NULL, ms->prompt, 0);
        	
        	
        	if (ms->my_kid != -1)
        	{
        	    waitpid(ms->my_kid, &ms->exit_status, 0);
        	    if (WIFEXITED(ms->exit_status))
        	        ms->exit_status = WEXITSTATUS(ms->exit_status);
        	    ms->my_kid = -1;
        	}
    	}
    	//printf("signal is %d\n", save_signal(NULL));
    	check_for_signals(ms);
	}
	return (1);
}



int main(int ac, char **av, char **env)
{
	t_ms	ms;
    
    (void)ac;
	if (!init_ms(&ms, &av[0][2], env))
		return (0);
    ms_prompt_loop(&ms);
	destroy_ms(&ms);
	return (0);
}

/*

se o infile falhar, o comando nao executa, erro tipo 1

ERROS: 

    perrors everywhere
    here doc com env expansion;
    
    signals..?

    perceber se o && precisa de esperar todos os processos ou só os antecedentes


*/

