/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.exec.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/01 12:32:48 by marvin            #+#    #+#             */
/*   Updated: 2023/06/01 12:32:48 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	perror_msg(char *text)
{
	perror(text);
	return (0);
}

int	error_msg(char *text)
{
	ft_putstr_fd(text, STDERR_FILENO);
	return (0);
}

int perror_msg_func(t_block *block, char *function, int errcode, int with_ms)
{
    if (block->father)
        block->father->my_status = errcode;
    else
        block->ms->exit_status = errcode;
    if (with_ms)
    {
        ft_putstr_fd(block->ms->name, block->ms->errfd);
        ft_putstr_fd(": ", block->ms->errfd);
    }
    perror(function);
    return (0);
}

void	error_child_exit(t_block *block, char *function, char *cmd, int errcode, int with_ms)
{
    if (block->father)
        block->father->my_status = errcode;
    else
        block->ms->exit_status = errcode;
    //printf("error code sent by child..? %d\n", block->ms->exit_status);
    if (with_ms)
    {
        ft_putstr_fd(block->ms->name, block->ms->errfd);
        ft_putstr_fd(": ", block->ms->errfd);
    }
    ft_putstr_fd(function, block->ms->errfd);
    ft_putstr_fd(": ", block->ms->errfd);
    ft_putstr_fd(cmd, block->ms->errfd);
    ft_putstr_fd("\n", block->ms->errfd);


    close(block->ms->infd);
	close(block->ms->outfd);

    destroy_ms(block->ms);
    exit(errcode);
}

void	perror_child_exit(t_block *block, char *function, int errcode, int with_ms)
{
    if (block->father)
        block->father->my_status = errcode;
    else
        block->ms->exit_status = errcode;
    if (with_ms)
    {
        ft_putstr_fd(block->ms->name, block->ms->errfd);
        ft_putstr_fd(": ", block->ms->errfd);
    }
    perror(function);

    //close fds
    close(block->ms->infd);
	close(block->ms->outfd);

    destroy_ms(block->ms);
    exit(errcode);
}


/*

    join_bin_path
    self explanatory, joining the bin to a single path, returning, and exec_cmd_search_path determines
    whether this is a valid path for execution

*/


int	join_path_bin(char **full_path, char *path, char *bin)
{
	int		path_len;
	int		bin_len;
	char	*new;

	path_len = ft_strlen(path);
	if (path[path_len - 1] == '/')
		path_len--;
	bin_len = ft_strlen(bin);
	new = malloc(sizeof(*new) * (path_len + bin_len + 1 + 1));
	if (!new)
	{
		*full_path = new;
		return (perror_msg("malloc"));
	}
	ft_memcpy(new, path, path_len);
	new[path_len] = '/';
	ft_memcpy(&new[path_len + 1], bin, bin_len);
	new[path_len + bin_len + 1] = '\0';
	*full_path = new;
	return (1);
}



/*

    checks if the absolute/relative address that was given is valid, and if so, executes
    otherwise, it returns the corrresponding error message and exits

*/


int	exec_cmd_with_path(t_block *block)
{
	if (access(block->cmd, F_OK))
		return (perror_msg(block->cmd));                                            //double check this
	else if (execve(block->cmd, block->cmd_args, block->ms->env) == -1)
		return (perror_msg(block->cmd));                                            //double check this
	return (1);
}

/*

    searches path on the $PATH env variable and tries the find the command
    it needs to execute from there

*/

int	exec_cmd_search_path(t_block *block)
{
	int		i;
	char	*full_path;

    if (!block->ms->path)
    {
        error_child_exit(block, block->cmd_args[0], ERR_CMD, CODE_CMD, 1);       // substituir
        return (0);
    }
	i = 0;
	while (block->ms->path[i])
	{
		if (!join_path_bin(&full_path, block->ms->path[i++], block->cmd))
			return (0);
		if (access(full_path, F_OK) == 0)
		{
			if (execve(full_path, block->cmd_args, block->ms->env) == -1)
			{
				perror_child_exit(block, block->cmd_args[0], CODE_EXECVE, 1);
				ft_free_set_null(&full_path);
				return (0);
			}
		}
		else
			ft_free_set_null(&full_path);
	}
	error_child_exit(block, block->cmd_args[0], ERR_CMD, CODE_CMD, 1);    //error messageeeeeee
	return (0);
}

/*

    exec_command
    straight forward, checks whether the path to the command is absolute/relative
    or $PATH is required to find the correct executable and calls the apropriate function
    to finish the job.

*/


int	exec_command(t_block *block)
{
	if (ft_strrchr(block->cmd, '/'))
		exec_cmd_with_path(block);
	else
		exec_cmd_search_path(block);
	return (0);
}

/*
    child_process
    redirects block->final file descriptors in order for the command called from execve
    to use them for input and output.
    After dup2, it closes the original file descriptors (not inherited) as these are not needed anymore
    If exec_command fails, it will exit. exec_command itself reports on the error found:
        -   command not found
        -   permissions
        -   etc
    Given that pipes are communication between children (even though they are set by the father)
    it is up to them to close them.
    If the current operation by the child is to wirte of the pipe, it is its responsibility
    to close the read-end since it will not use it. WIthout that, there will be always a reference to
    the read-end of the pipe, it is never closed, and another process that is reading will assume the piep is open.
    This child has to close the read-end and force a SIGPIPE on the following process to guarantee that
    the next one isn't kept waiting by a pipe that is no longer under use.
    Upon returning to the execution_tree function, the function will call destroy block to make sure that
    it is over.
    In fact, exec command itself will exit and report on the exit status of failure and avoiding the child process
    to continue past this function.

*/

int	child_process(t_block *block)
{
    if (dup2(block->final_in, block->ms->infd) == -1)
        perror_child_exit(block, block->cmd_args[0], CODE_DUP2, 1);
    close_in_fds(block);
    if (dup2(block->final_out, block->ms->outfd) == -1)
        perror_child_exit(block, block->cmd_args[0], CODE_DUP2, 1);
    close_out_fds(block);
	if (!exec_command(block))
		return (0);
	return (0);
}

/*
    parent_process
    Closes the oustanding file descriptors that are not inherited or are pipes
    frees block->here_doc after unlinking, in order to destroy the here_doc used
    as infput, if such was the case.
*/

int	parent_process(t_block *block, pid_t pid)
{
    close_in_fds(block);
	close_out_fds(block);
	if (block->here_doc)
	{
		unlink(block->here_doc);
		ft_free_set_null(&block->here_doc);
	}
	if (block->i_am_forked)
	{
    	waitpid(pid, &block->my_status, 0);
        if (WIFEXITED(block->my_status))
            block->my_status = WEXITSTATUS(block->my_status);
	}
	return (1);
}

/*
    process_execution
    This is called inside the "execute" function, close to main function, after all cmd_args and
    fds are correctly setup.
    It forks the process, saves the pid in the father block (as the father will need to know for which
    children to wait for) and, based on the return of pid, does both the child process and the parent process.

*/

int	process_execution(t_block *block)
{
	pid_t   pid;
	int		builtin;
    
    printf("ms status %d before calling hello\n", block->ms->exit_status);
	builtin = check_builtins(block);
	if (!builtin)
	{
		pid = fork();
		if (block->i_am_forked == 0)
		{
			if (block->father)
				block->father->child_pids[block->my_id] = pid;
			else
				block->ms->my_kid = pid;
		}
		if (pid == -1)
			return (perror_msg("fork"));
		if (!pid)
			child_process(block);
		parent_process(block, pid);
	}
	else
		return (exec_builtin(block, builtin));
	return (1);
}


char	*ft_strchr(const char *s, int c)
{
	while (*s != (char)c)
	{
		if (*s == '\0')
			return (NULL);
		s++;
	}
	return ((char *)s);
}

int	check_builtins(t_block *block)
{
	if (ft_strncmp(block->cmd, "cd", 3) == 0)
		return (BI_CD);
	else if (ft_strncmp(block->cmd, "env", 4) == 0)
		return (BI_ENV);
	else if (ft_strncmp(block->cmd, "pwd", 4) == 0)
		return (BI_PWD);
	else if (ft_strncmp(block->cmd, "echo", 5) == 0)
		return (BI_ECHO);
	else if (ft_strncmp(block->cmd, "exit", 5) == 0)
		return (BI_EXIT);
	else if (ft_strncmp(block->cmd, "unset", 6) == 0)
		return (BI_UNSET);
	else if (ft_strncmp(block->cmd, "export", 7) == 0)
		return (BI_EXPORT);
	return (0);
}

int	exec_builtin(t_block *block, int builtin)
{
	if (builtin == BI_CD)
		return (1);											//replace run_cd
	else if (builtin == BI_ENV)
		return (run_env(block));
	else if (builtin == BI_PWD)
		return (run_pwd(block));
	else if (builtin == BI_ECHO)
		return (run_echo(block));
	else if (builtin == BI_EXIT)
		return (run_exit(block));
	else if (builtin == BI_UNSET)
		return (1);
	else if (builtin == BI_EXPORT)
		return (1);
	return (1);
}


/*
block->ms->env;     //copia do env
block->cmd_args      // char **av, ja limpo de expansoes, quotes, etc
block->final_out;	// fd para escrever com ft_putstr_fd
block->final_in;    // fd para ler tipo gnl (n/a)

*/

int	run_pwd(t_block *block)
{
	char	*pwd;

	pwd = getcwd(NULL, 0);
	if (!pwd)
		return (perror_msg("malloc"));
	ft_putstr_fd(pwd, block->final_out);
	write(block->final_out, "\n", 1);
	free(pwd);
	return (1);
}

/*



int	run_cd(t_block *block, char **cmd, char **env, int final_out)
{
	int		i;
	char	*curr;
	char	*curpath;

	curr = getcwd(NULL, 0);								//malloc can fail
	curpath = set_beg_path(cmd, env, 0, curr);
	if (!curpath || !cmd[1])
	{
		if (curpath)
			free(curpath);
		free(curr);
		return ;
	}
	if (cd_exists(cmd[1], curpath, final_out) == 0)
		return (free(curr));
	i = 0;
	while (ft_strnstr(env[i], "OLDPWD=/", ft_strlen(env[i])))
		i++;
	if (env[i] && chdir(curpath) == 0)
		env[i] = ft_strjoin("OLDPWD=", curr);				// malloc can fail
	printf("%s\n", env[i]);
	free(env[i]);
	free(curpath);
	free(curr);
	return (1);
}

char	*set_beg_path(char **cmd, char **env, char *curpath, char *curr)
{
	int		i;

	i = 0;
	while (ft_strncmp(env[i], "HOME=", 5) != 0)
		i++;
	if (!cmd[1] && !env[i])
	{
		free(curr);
		return (NULL);
	}
	else if (!cmd[1] && env[i])
		curpath = ft_strdup(&env[i][5]);
	else if (cmd[1] && cmd[1] == '-' && !cmd[2])
	{
		i = 0;
		while (ft_strnstr(env[i], "OLDPWD=/", ft_strlen(env[i])))
			i++;
		curpath = ft_strdup(&env[i][5]);
	}
	else
		curpath = aux_cd_paths(cmd[1], curpath, curr);
	free(curr);
	return (curpath);
}

static char	*aux_cd_paths(char *cmd, char *curpath, char *curr)
{
	int		i;
	char	*temp;

	i = 0;
	if (cmd && cmd[0] == '/')
	{
		curpath = ft_strdup(cmd);						//malloc, perror_msg
		i = ft_strlen(curpath);
		while (curpath[--i] == '.' || (curpath[i] == '/' \
		&& i - 1 >= 0 && curpath[i - 1] == '.'))
			curpath[i] = 0;
	}
	else
	{
		if (curr[ft_strlen(curr)] != '/')
			temp = ft_strjoin(curr, "/");
		else
			temp = ft_strdup(curr);
		// test teemp and perror_msg;
		curpath = ft_strjoin(temp, cmd);				//malloc, perror_msg
		free(temp);
	}
	return (curpath);
}

int	cd_exists(char *cmd, char *curpath, int final_out)
{
	char	*curr;
	char	*temp;
	// int		i;

	// i = 0;
	if (curpath)
	{
		if (chdir(curpath) != 0)
		{
			write(1, "minishell: ", 11);
			ft_putstr_fd(cmd, final_out);
			write(1, ": No such file or directory\n", 28);
			free(curpath);
			return (0);
		}
		temp = getcwd(NULL, 0);								// malloc can fail
		curr = ft_strjoin("PWD=", temp);					// malloc can fail
		free(temp);
		// while (ft_strnstr(env[i], "PWD=/", ft_strlen(env[i])))
		// 	i++;
		// env[i] = 0;
		// env[i] = ft_strdup(curr);
		printf("%s\n", curr);
		free(curr);
	}
	return (1);
}
*/


int	run_env(t_block *block)
{
	int	i;

	i = 0;
	if (!block->ms->env)
		return (1);
	while (block->ms->env[i])
	{
		ft_putstr_fd(block->ms->env[i], block->final_out);
		write(block->final_out, "\n", 1);
		i++;
	}
	return (1);
}

void	env_remove(char **env, int i)
{
	while (env[i] && env[i + 1])
	{
		env[i] = env[i + 1];
		i++;
	}
	env[i] = NULL;
}

int	get_corr_env(char *cmd, char **env)
{
	int		i;
	size_t	f;
	size_t	j;

	i = 0;
	j = 0;
	while (cmd[j] && cmd[j] != '=')
		j++;
	while (env[i])
	{
		f = 0;
		while (env[i][f] && env[i][f] != '=')
			f++;
		if (f < j)
			f = j;
		if (ft_strncmp(env[i], cmd, f) == 0)
			return (i);
		i++;
	}
	return (-1);
}

void	env_substitute(char *cmd, char **env, int i)
{
	size_t	f;

	f = 0;
	while (env[i][f] && env[i][f] != '=')
		f++;
	if (!env[i][f])
		return ;
	f--;
	env[i] = 0;
	env[i] = malloc(ft_strlen(cmd) + f + 1);
	if (!env[i])
		return ;								//perror_msg
	env[i + ft_strlen(cmd) + 1] = cmd;
}

void	env_add(char *cmd, char **env)
{
	size_t	f;

	f = 0;
	while (env[f])
		f++;
	env[f] = malloc(ft_strlen(cmd) + f);
	if (!env[f])
		return ;								//perror_msg
	env[f] = cmd;
}

int	run_echo(t_block *block)
{
	int		i;
	int		jump;

	i = 0;
	jump = 0;
	if (block->cmd_args[1] && ft_strncmp(block->cmd_args[1], "-n", 2) == 0)
	{
		i++;
		while (block->cmd_args[1][i] && block->cmd_args[1][i] == 'n')
			i++;
		if (!block->cmd_args[1][i])
			jump = 1;
		i = jump;
	}
	while (block->cmd_args[++i])
	{
		if (i > 1 + jump && ft_strlen(block->cmd_args[i - 1]) > 0)
			write(block->final_out, " ", 1);
		ft_putstr_fd(block->cmd_args[i], block->final_out);
	}
	if (jump == 0)
		write(block->final_out, "\n", 1);
	return (1);
}

/*
exit: too many arguments, doesn't exit, exit_status 1;
exit: non-numeric argument writes to stderr, STILL EXITS, exit_status 2;
    -   strict, a number with a plus or minus sign and nothing else

ORDER:
    checks if the first argument is valid
        if it is not valid, EXITS "non-numeric" exit_status 2;
        
        else
            check if there are more arguments
        if there are more arguments, "too many arguments", DOES NOT EXIT, status 1

*/

int exit_execution(t_block *block, char *arg, int is_exiting, int is_error)
{
    int save_status;
    
    if (!block->i_am_forked)                                                    //só escreve stdou se for o main process a chamar
        ft_putstr_fd("exit\n", block->ms->outfd);                                 // confirm if it is standard error or out or wtvs
    if (is_error)
    {
        ft_putstr_fd(block->ms->name, block->ms->errfd);
        ft_putstr_fd(": exit: ", block->ms->errfd);
        if (arg)
        {
            ft_putstr_fd(arg, block->ms->errfd);
            ft_putstr_fd(": numeric argument required\n", block->ms->errfd);
        }
        else
            ft_putstr_fd("too many arguments\n", block->ms->errfd);
    }
    if (is_exiting)
    {
        save_status = block->my_status;
        destroy_ms(block->ms);
        exit(save_status);
    }
    else if (block->father)
        block->father->my_status = block->my_status;
    else
        block->ms->exit_status = block->my_status;
    return (1);
}

int  exit_atoi(char *arg, int *place_res)
{
	int	res;
	int	sign;

	sign = 1;
	while (*arg && ft_isspace(*arg))
		arg++;
	if (*arg == '-')
		sign = -1;
	if (*arg == '-' || *arg == '+')
		arg++;
	if (!(*arg >= '0' && *arg <= '9'))
	    return (0);
	res = 0;
	while (*arg >= '0' && *arg <= '9')
		res = res * 10 + (*arg++ - '0');
	while (*arg && ft_isspace(*arg))
		arg++;
	if (*arg)
	    return (0);
	*place_res = res * sign % UCHAR_MAX;
	return (1);
}

int	run_exit(t_block *block)
{
    if (block->cmd_args[1])
    {
        if (!exit_atoi(block->cmd_args[1], &block->my_status))
        {
            block->my_status = 2;                                    //EXIT_CODE  non_numerical value = 2, SUBSTITUTE WITH MACRO;
            exit_execution(block, block->cmd_args[1], 1, 1);
        }
        else if (block->cmd_args[2])
        {
            block->my_status = 1;                                   //EXIT_CODE  too many args = 1, SUBSTITUTE WITH MACRO;
            exit_execution(block, NULL, 0, 1);
        }
        else
            exit_execution(block, NULL, 1, 0);                      //clean exit
    }
    else
        exit_execution(block, NULL, 1, 0);                      //clean exit without arguments, exits with whatever there was
    return (1);
}

int	run_unset(t_block *block)
{
	int		i;
	int		j;

	if (!block->ms->env)
		return (1);
	j = 0;
	while (block->cmd_args[++j])
	{
		i = get_corr_env(block->cmd_args[j], block->ms->env);
		if (i != -1)
			env_remove(block->ms->env, i);
	}
	return (1);
}


/*
void	run_export(char **cmd, char **env, int final_out)
{
	int		i;
	int		j;

	j = 0;
	if (!cmd[1])
		run_env(env, final_out);
	else
	{
		while (cmd[++j])
		{
			i = get_corr_env(cmd[j], env);
			if (i == -1)
				env_add(cmd[j], env);
			else
				env_substitute(cmd[j], env, i);
		}
	}
	run_env(env, final_out);
}
*/
